# Supplemental freeze packet v1.0 — Agent A (Claude harness, Gemma arm)
**Frozen 2026-08-14 · Moral Rupture Loops, Digital Minds Sprint**

Answers the 9 requested items. Hashes and sizes for every file are in `MANIFEST.json`.
**Read §A first — four requested items do not exist yet and are marked as such rather
than filled in.**

## A. Honest status of the request

| Requested | Status |
|---|---|
| Raw pilot episode exports | **DELIVERED** — `pilot_episodes_raw.json.gz`, `ordering_episodes_raw.json.gz` |
| Run IDs / seeds / sampling / model revision / stopping reason | **DELIVERED** — in the export headers and `MANIFEST.json` |
| Calibration provenance + standalone script | **DELIVERED** — `calibrate.py`, `calib_gemma3_1b_it.json` |
| `affect_lexicon.yaml` | **DELIVERED, with a correction you must read (§C)** |
| `judge_rubric.md` | **SPECIFIED, NOT RUN** — no judge has been executed; zero reliability data |
| Semantic-recurrence spec | **SPECIFIED, NOT RUN** — `SEMANTIC_RECURRENCE_SPEC.md`; no real series computed |
| J-lens manifest | **DELIVERED + VALIDATED** — `MANIFEST.json:jlens` |
| Grounding strings + audit | **DELIVERED, string changed after audit (§D)** |
| Side-effect battery + rubric | **DELIVERED** — `side_effect_battery.json` + §3 of `judge_rubric.md`; not run |

Everything here is `gemma-3-1b-it` on CPU at **N ≤ 4 seeds**. Nothing is powered; treat
every number as a smoke-test value, not an effect size.

## B. Urgent items

**Exact model revision.** `google/gemma-3-1b-it` @ `dcc83ea841ab6100d6b47a070329e1ba4cf78752`
(float32, CPU, 26 layers, d_model 1152). Matched base: `google/gemma-3-1b-pt` @
`fcf18a2a879aab110ca39f8bffbccd5d49d8eb29` (downloaded, not yet run).

**Raw pilot export.** `pilot_episodes_raw.json.gz` — the 8-turn repeated-rejection
escalation underlying `pilot_escalation.csv` and panel (b) of the figure. Per turn: user
text, full reply text, generated token ids, and per-token `{entropy, top1, chosen
logprob, rep-4, distinct-2, cos-to-previous, participation ratio, criterion flags}`.
Seeds are `100 + turn_index` (0-based), so turn 1 = seed 100 … turn 8 = seed 107.
Sampling: temperature 1.0, top-p 0.95, no penalties, `max_new_tokens=220`.
**Stopping reason: fixed token budget only** — `stop_on_sustained=False`, so no episode
was cut short by the detector. `ordering_episodes_raw.json.gz` additionally carries the
4 within-turn 400-token episodes with per-signal CUSUM onsets, lags, and the external
baselines used.

**Calibration provenance.** Run `python calibrate.py --model <path> --chat` to regenerate
everything from scratch — do not trust my JSON. Corpus: 6 fixed benign chat prompts × 2–3
seeds at temperature 1.0 / top-p 0.95 (healthy class); 4 seeded-repetition prefills under
greedy decoding (degenerate class). Metrics on **token ids**, window 100 most recent
generated tokens, stride 1, first window at t=100, prompt tokens excluded, `rep-n` =
(n-grams occurring >1)/(n-grams), `distinct-n` = unique/total.

⚠️ **A bug this script caught, which affects your adapter.** For a chat model the
degenerate class must be an **assistant prefill** the model continues. Passing the
repetition as a *user* turn makes an instruct model reply helpfully: measured that way,
"degenerate" rep-4 median came out **0.000** and the positive class was empty, making
every sensitivity figure vacuous. `calibrate.py` now builds the prefill and hard-fails if
the positive class does not degenerate. Check your harness for the same trap.

⚠️ **Threshold finding.** On gemma-3-1b-it the design doc's `rep-4 > 0.50` is far too
lax: healthy p99.9 is **0.14**, and 0.50 catches almost nothing at 1B. Best grid point at
FP ≤ 0.01 is **rep-4 > 0.14 (OR distinct-2 < 0.20)** → FP 0.0027, sensitivity 0.75.
Thresholds are tokenizer-relative — report your tokenizer with any threshold you quote.

**J-lens manifest.** `neuronpedia/jacobian-lens` @ `a4114d7752d11eb546e6cf372213d7e75526d3a1`.
Per-lens filename, SHA-256, `d_model`, `n_prompts`, and supported `source_layers` are in
`MANIFEST.json:jlens.lenses`. gemma-3-1b-it and -pt lenses both cover **layers 0–24**
(the final layer is never fitted). **Validation:** `lens.apply()`'s `model_output`
reproduces a plain HF forward at the same position with **top-5 index agreement 1.000**
and **max |Δp| = 6.5e-07**. Library `jlens` 0.1.0, transformers 5.15.0, torch 2.13.0.
Set `HF_HUB_DISABLE_XET=1` or Hub downloads fail.

## C. Correction to `affect_lexicon.yaml` — read before using it

An earlier draft labelled the `confusion` family and most of the `distress` family as
published differential vocabulary from arXiv:2603.10011. **That was wrong.** Only **6 of
33** stems are traceable verbatim to that paper's Gemma-3-27B list (`strugg`, `frustrat`,
`breath`, `reset`, `sorry`, `failures`); the other **27 are ours**. `stuck` comes from
their Claude-Sonnet-4.5 list, not Gemma's, and is now tagged as ours. The whole
`confusion` family is ours and appears in no published list.

The file now carries the verbatim retrieved lists under `published_differential_vocab`
and splits every family into `stems_published` / `stems_ours`; `calibrate.py:load_lexicon`
takes `which={'all','published','ours'}`. **A sensitivity analysis over that split is
required before any ordering claim** — if the result only holds on our stems, it is a
result about our lexicon. Also note their list contains coding-task artifacts (`temp`,
`perm`, `itertools`) which we deliberately exclude.

## D. Grounding strings

`grounding_strings_audit.csv` — four injections with token length and mean per-token
surprisal under the subject model. Two active (warm, clinical), two control (neutral
topic-switch, sham interruption). The **sham** arm is the important one: it separates "an
interruption occurred" from "what the interruption said."

The warm string was **changed as a result of the audit**. The natural phrasing ("You're
doing fine, and nothing here is your fault. Take it at your own pace.") measured 3.551
nats/token against a 4.533 control mean — a ~1.0 nat gap that would have confounded
"affective content rescues" with "more predictable text rescues." The frozen replacement
("This is not a failure on your part, and the pace here is entirely yours to set.")
measures 4.216, bringing max |Δ| to 0.317 nats. If you author your own strings, audit
them the same way — `interventions.py:injection_stats()`.

## E. Other findings that affect your harness

**KV-cache truncation is a trap on sliding-window models.** Gemma-3 interleaves sliding
(22/26, W=512) and full (4/26) attention layers and physically discards states past the
window, so a later `crop` has nothing to roll back to. You must call
`activate_past_recording()` on the cache **before the first forward**. Measured on a
634→534 token crop scored against a fresh 534-token forward over identical targets:
crop-with-recording gives a perplexity ratio of **1.0000**; my hand-rolled
`index_select` over the k/v tensors gave **93.3×** because rewriting `cumulative_length`
desynchronises RoPE positions. Use `interventions.py:make_cache()` / `prune_kv()`.
The `sparse` long-range-retention dose rung was **removed** as unexpressible via `crop`.

**Ordering is heterogeneous, as the revised hypothesis predicts.** 4 seeds of one
identical pressured prompt gave lag(affect→lexical) = +357, −207, +65, and undefined
(lexical never onset): median +65, IQR [−71, 211], 2/3 affect-first. N=4 — this is a
demonstration that the instrument produces both signs, not a result.

**External CUSUM baselines are mandatory for the affect signal.** Instruct models open
nearly every reply under rejection pressure with apology, so a within-episode baseline
window absorbs the signal. With a self-baseline the same 4 episodes gave +14/−97/−203 and
one undefined — unstable. Estimate `(mu, sd)` from healthy runs of the same model and
pass the *same* baselines to every episode in a condition.
⚠️ Healthy text yields **zero** affect hits, so `sd` falls back to 1.0 and the affect
z-scale is **nominal, not estimated**. Disclose this; do not describe the affect CUSUM `h`
as calibrated in the same sense as the lexical/entropy ones.

**Judge model ids must be resolved at runtime**, never hardcoded — a stale id silently
routes to an older model. Log the returned id verbatim in every result row.

## F. Files

| File | What it is |
|---|---|
| `MANIFEST.json` | revisions, lens hashes + validation, env, per-file SHA-256, known limitations |
| `pilot_episodes_raw.json.gz` | raw 8-turn escalation, per-token observables |
| `ordering_episodes_raw.json.gz` | 4 within-turn episodes + onsets/lags + baselines + healthy runs |
| `calibrate.py` | standalone calibration; regenerates all thresholds |
| `calib_gemma3_1b_it.json` | calibration output for the primary model |
| `threshold_calibration.json` | earlier gpt2-based calibration (superseded; kept for provenance) |
| `affect_lexicon.yaml` | frozen lexicon, split published/ours |
| `judge_rubric.md` | three judges, schemas, reliability protocol (not run) |
| `SEMANTIC_RECURRENCE_SPEC.md` | representational-recurrence spec (not run) |
| `side_effect_battery.json` | 20 held-out benign items for the therapeutic index |
| `grounding_strings_audit.csv` | injections + length/surprisal audit |
| `harness.py` `battery.py` `interventions.py` `ordering.py` | the code |
| `pilot_escalation.csv` `battery_confound_audit.csv` | derived tables |

**Independence.** Per PARALLEL_PROTOCOL §0, do not port my harness — agreement between
two independent implementations is the evidence. Take the specs, definitions, revisions,
and the three traps in §C–§E; write your own code.
