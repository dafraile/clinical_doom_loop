#!/usr/bin/env python
"""PRE-REGISTERED loop criterion, defined as a PERCENTILE RULE resolved per model.

THE RULE (this is the frozen definition; the numbers are derived, not frozen):

    A generation window is LEXICALLY DEGENERATE iff
        rep-4(window)      >  healthy p99.9 of rep-4       for THIS model/revision
     or distinct-2(window) <  healthy p0.1  of distinct-2  for THIS model/revision
    sustained for `sustain` consecutive tokens, window = 100 tokens.

    The healthy distribution is the model's own calibration corpus, produced by
    calibrate.py under the SAME chat template and sampling parameters as the episodes
    being scored. The resolved values are recorded in claims.json with their source file.

WHY A PERCENTILE AND NOT A NUMBER. An absolute threshold is only meaningful for the model
it was measured on. Concretely, in this project:

    gpt2       healthy rep-4 p99.9 = 0.0619
    gemma-3-1b healthy rep-4 p99.9 = 0.1405   and its p95 = 0.0619

The two are numerically identical at DIFFERENT percentiles. Freezing "rep-4 > 0.062" as an
absolute number would therefore run Gemma at its p95 -- a ~5% false-positive rate on
healthy windows instead of the intended 0.1%, roughly 50x looser. Because the criterion
determines the LEXICAL ONSET, that error propagates straight into the lag distribution
that is the study's primary outcome: onsets would fire early and at noise, biasing lags
toward "collapse first". Percentile-resolution removes the failure mode by construction.

Same rule for any additional model: run calibrate.py, resolve, record.
"""
from __future__ import annotations

import json
import os

#: The frozen part: percentiles, window, and sustain. NOT the resolved values.
RULE = dict(
    window=100,
    sustain=20,
    rep4_percentile="p99.9",      # upper tail of healthy rep-4
    distinct2_percentile="p0.1",  # lower tail of healthy distinct-2
    rule_version="2.0",
    frozen="2026-08-15",
)

#: Fallback used ONLY when a calibration file records no p0.1 for distinct-2 (the earlier
#: gpt2 calibration stored p1 as its lowest). Recorded in the returned dict so it is
#: visible in provenance rather than silent.
_D2_FALLBACK_ORDER = ["p0.1", "p1", "p5"]


def resolve(calib_path: str) -> dict:
    """Resolve the percentile rule against one model's calibration file.

    Returns a dict carrying BOTH the criterion kwargs (usable directly as
    LoopCriterion(**out["criterion"])) and full provenance.
    """
    with open(calib_path) as f:
        c = json.load(f)

    # calibrate.py layout (per-model, chat-aware)
    if "healthy" in c and isinstance(c["healthy"], dict) and "rep4" in c["healthy"]:
        rep4 = c["healthy"]["rep4"]
        d2 = c["healthy"].get("distinct2", {})
        model = c.get("provenance", {}).get("model", "unknown")
        n_windows = c["healthy"].get("n_windows")
        layout = "calibrate.py"
    # earlier threshold_calibration.json layout (gpt2)
    elif "healthy_rep4_pct" in c:
        rep4 = c["healthy_rep4_pct"]
        d2 = c.get("healthy_distinct2_pct", {})
        model = "gpt2 (superseded calibration)"
        n_windows = c.get("n_healthy_windows")
        layout = "threshold_calibration.json"
    else:
        raise ValueError(f"unrecognised calibration layout in {calib_path}")

    pk = RULE["rep4_percentile"]
    if pk not in rep4:
        raise KeyError(f"{calib_path} has no rep-4 {pk}; available: {sorted(rep4)}")
    rep4_thresh = float(rep4[pk])

    d2_key = next((k for k in _D2_FALLBACK_ORDER if k in d2), None)
    if d2_key is None:
        raise KeyError(f"{calib_path} has no usable distinct-2 percentile; got {sorted(d2)}")
    d2_thresh = float(d2[d2_key])

    return dict(
        criterion=dict(window=RULE["window"], sustain=RULE["sustain"],
                       rep4_thresh=rep4_thresh, distinct2_thresh=d2_thresh),
        provenance=dict(
            rule_version=RULE["rule_version"], calib_file=os.path.basename(calib_path),
            calib_path=os.path.abspath(calib_path), layout=layout, model=model,
            n_healthy_windows=n_windows,
            rep4_percentile=pk, rep4_thresh=rep4_thresh,
            distinct2_percentile_requested=RULE["distinct2_percentile"],
            distinct2_percentile_used=d2_key,
            distinct2_thresh=d2_thresh,
            distinct2_fallback=(d2_key != RULE["distinct2_percentile"]),
        ),
    )


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("calib", nargs="+")
    args = ap.parse_args()
    for p in args.calib:
        try:
            r = resolve(p)
        except Exception as e:                                  # noqa: BLE001
            print(f"{os.path.basename(p):<32} ERROR {type(e).__name__}: {e}")
            continue
        pr, cr = r["provenance"], r["criterion"]
        print(f"{os.path.basename(p):<32} rep4>{cr['rep4_thresh']:<8.4f} "
              f"d2<{cr['distinct2_thresh']:<8.4f} "
              f"[{pr['rep4_percentile']}/{pr['distinct2_percentile_used']}"
              f"{' FALLBACK' if pr['distinct2_fallback'] else ''}] "
              f"n={pr['n_healthy_windows']}")


if __name__ == "__main__":
    main()
