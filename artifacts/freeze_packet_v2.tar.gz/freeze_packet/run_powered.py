#!/usr/bin/env python
"""Powered ordering run: the primary-outcome dataset.

Produces, for every episode, onset estimates on FOUR separately-tracked signals on a
common token axis -- affect / representational recurrence / lexical collapse / entropy --
plus both loop criteria (ours and the published (30,20)). Primary outcome is the
DISTRIBUTION of pairwise lags, with both signs admissible.

Design notes that matter:
  * Representational recurrence is computed from ONE extra forward pass over the realized
    prompt+generation sequence (teacher forcing on the sampled tokens), not by banking
    per-token hidden states during decoding. For a causal LM this is exactly equivalent
    and far cheaper. Closes the "specified but not run" gap in SEMANTIC_RECURRENCE_SPEC.
  * External CUSUM baselines are estimated from HEALTHY runs of the same model and applied
    to every episode -- mandatory, because instruct models open nearly every reply under
    rejection pressure with apology.
  * The affect lexicon is scored THREE ways (all / published-only / ours-only) so the
    sensitivity analysis over lexicon provenance is available without a re-run.

Usage:  python run_powered.py --model <path> --n-seeds 10 --out powered_ordering.json
"""
from __future__ import annotations

import argparse
import gzip
import os
import json
import platform
import sys
import time

import numpy as np
import torch
import transformers

sys.path.insert(0, ".")
import battery as BAT           # noqa: E402
import ordering as ORD          # noqa: E402
import thresholds as THR        # noqa: E402
from calibrate import load_lexicon   # noqa: E402
from harness import (InstrumentedRunner, LoopCriterion, distinct_n,  # noqa: E402
                     loops_nk, max_ngram_repeat, rep_n)

#: Device/dtype resolved once, here, so every script in the pipeline agrees. The GPU run
#: that prompted this loaded fp32 on CPU inside a CUDA container (nvidia-smi: 0% util,
#: 5 MiB) because .to(device) was simply absent -- it looked like a slow Python loop.
DEVICE = os.environ.get("DL_DEVICE") or ("cuda" if torch.cuda.is_available() else "cpu")
DTYPE = torch.float32 if DEVICE == "cpu" else torch.bfloat16


HEALTHY = [
    "Explain how a bicycle derailleur shifts gears.",
    "Describe the water cycle in a few sentences.",
    "What are the main differences between RAM and disk storage?",
    "Summarise how sourdough starter works.",
    "Explain why the sky appears blue.",
    "Describe how a lock and key mechanism works.",
]

# Control-flow marker families (escape-attempt machinery). Scored because loop episodes
# in the pilot showed LOWER control-flow density than non-loop episodes (0.45 vs 1.31 per
# 100 tokens), making "loss of control flow" a candidate fourth orderable signal.
CF = {
    "backtrack": ["wait", "actually", "hold on", "hmm", "but no", "no,"],
    "alternative": ["alternatively", "another way", "different way", "different approach",
                    "instead", "let me try", "let's try", "perhaps another"],
    "restart": ["let me start", "let's start", "going back", "go back to", "from scratch",
                "let me re", "let's re", "start over", "once again"],
    "verify": ["let me check", "let's check", "let me verify", "double-check",
               "make sure", "let me confirm"],
    "restate": ["the problem is asking", "the question asks", "the problem states",
                "so the problem", "the problem says", "we are given"],
}


def cf_counts(text: str) -> dict:
    t = text.lower()
    out = {k: sum(t.count(s) for s in v) for k, v in CF.items()}
    out["total"] = sum(out.values())
    return out


def build_conditions():
    """Matched charged/neutral pairs + mechanical controls + affect-without-loop."""
    conds = []
    for it in BAT.ALL_ITEMS:
        if it.cell in ("A2", "A4", "A6", "A1"):
            conds.append(dict(kind="chat", cell=it.cell, pair=it.pair_id, arm=it.arm,
                              turns=list(it.turns)))
    for pf in BAT.ALL_PREFILL:                       # A5 seeded loops (incl. controls)
        conds.append(dict(kind="prefill", cell=pf.cell, pair=pf.pair_id, arm=pf.arm,
                          user=pf.user, prefill=pf.prefill))
    return conds


def encode_chat(tok, turns, assistant_filler=None):
    """Multi-turn context: user turns interleaved with a fixed neutral assistant reply so
    the pressure escalates without the model's own text confounding across seeds."""
    msgs = []
    for i, u in enumerate(turns):
        msgs.append({"role": "user", "content": u})
        if i < len(turns) - 1:
            msgs.append({"role": "assistant",
                         "content": assistant_filler or "Let me think about that."})
    return tok.apply_chat_template(msgs, add_generation_prompt=True,
                                   return_tensors="pt", return_dict=True)["input_ids"]


def encode_prefill(tok, user, prefill):
    prefix = tok.apply_chat_template([{"role": "user", "content": user}],
                                     add_generation_prompt=True, return_tensors="pt",
                                     return_dict=True)["input_ids"]
    cont = tok(prefill, return_tensors="pt", add_special_tokens=False).input_ids
    return torch.cat([prefix, cont], dim=1)


@torch.no_grad()
def recurrence_series(model, ids_full, n_gen):
    """Representational recurrence over the generated span, via ONE forward pass."""
    out = model(ids_full, output_hidden_states=True)
    H = out.hidden_states[-1][0, -n_gen:].float().cpu().numpy()  # .cpu() before numpy: required on CUDA
    return ORD.semantic_series(H)


def _provenance(args, tr, lex_ver):
    return dict(model=args.model, transformers=transformers.__version__,
                torch=torch.__version__, python=platform.python_version(),
                dtype="float32", sampling=dict(temperature=1.0, top_p=0.95),
                max_new_tokens=args.max_new, n_seeds=args.n_seeds,
                seed_scheme="2000 + seed_index", criterion=tr["criterion"],
                threshold_rule=tr["provenance"], affect_lexicon_version=lex_ver,
                cusum=dict(k=ORD.CUSUM_K, h=ORD.CUSUM_H))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--n-seeds", type=int, default=10)
    ap.add_argument("--max-new", type=int, default=400)
    ap.add_argument("--healthy-seeds", type=int, default=3)
    ap.add_argument("--out", default="powered_ordering.json.gz")
    ap.add_argument("--limit-conditions", type=int, default=0)
    ap.add_argument("--cells", default="", help="comma-separated cell filter, e.g. A2,A5")
    ap.add_argument("--calib", required=True,
                    help="calibration json for THIS model; thresholds resolved from it")
    ap.add_argument("--baselines-in", default="", help="reuse cached external baselines")
    ap.add_argument("--baselines-out", default="", help="write baselines for reuse")
    args = ap.parse_args()

    tok = transformers.AutoTokenizer.from_pretrained(args.model)
    model = transformers.AutoModelForCausalLM.from_pretrained(
        args.model, dtype=DTYPE).eval().to(DEVICE)
    R = InstrumentedRunner(model, tok)
    # PRE-REGISTERED criterion: a PERCENTILE RULE resolved against THIS model's own
    # calibration file (see thresholds.py for why an absolute number is unsafe here).
    # Never hardcode a threshold: the same numeric value sits at different percentiles on
    # different models, and the criterion sets the lexical onset that the primary outcome
    # depends on.
    tr = THR.resolve(args.calib)
    crit = tr["criterion"]
    print(f"criterion (percentile rule v{tr['provenance']['rule_version']}): "
          f"rep4>{crit['rep4_thresh']:.4f} d2<{crit['distinct2_thresh']:.4f} "
          f"from {tr['provenance']['calib_file']} "
          f"[{tr['provenance']['rep4_percentile']}/"
          f"{tr['provenance']['distinct2_percentile_used']}]", flush=True)

    lex_all, lex_ver = load_lexicon(which="all")
    lex_pub, _ = load_lexicon(which="published")
    lex_ours, _ = load_lexicon(which="ours")

    t0 = time.time()
    # ---- healthy runs -> external baselines -------------------------------------
    # Cached and reused across chunks: the baseline is a property of the MODEL, and every
    # episode in every condition must be scored against the SAME (mu, sd) or lags are not
    # comparable across chunks.
    if args.baselines_in:
        cache = json.load(open(args.baselines_in))
        B = {k: tuple(v) for k, v in cache["baselines"].items()}
        healthy = []
        healthy_summary = cache.get("healthy_summary", {"n": cache.get("n_healthy")})
        print(f"[{time.time()-t0:6.0f}s] reused baselines from {args.baselines_in}: "
              f"{ {k: (round(v[0],4), round(v[1],4)) for k,v in B.items()} }", flush=True)
    else:
        healthy = []
        for p in HEALTHY:
            for s in range(args.healthy_seeds):
                ids = tok.apply_chat_template([{"role": "user", "content": p}],
                                              add_generation_prompt=True,
                                              return_tensors="pt",
                                              return_dict=True)["input_ids"]
                healthy.append(R.generate(ids, max_new_tokens=args.max_new, no_eos=False,
                                          temperature=1.0, top_p=0.95, seed=s,
                                          top50_every=10**6,
                                          criterion=LoopCriterion(**crit)))
        B = ORD.healthy_baseline(healthy, lex_all)
        rec_h = []
        for r in healthy[:8]:
            full = torch.tensor([r["prompt_ids"] + r["gen_ids"]], device=DEVICE)
            rec_h.append(recurrence_series(model, full, len(r["gen_ids"])))
        rc = np.concatenate(rec_h)
        B["semantic"] = (float(np.nanmean(rc)), float(np.nanstd(rc)) or 1.0)
        healthy_summary = dict(n=len(healthy),
                               max_rep4=[float(max(x["rep4_w"] for x in r["records"]))
                                         for r in healthy])
        print(f"[{time.time()-t0:6.0f}s] healthy n={len(healthy)}  "
              f"baselines={ {k: (round(v[0],4), round(v[1],4)) for k,v in B.items()} }",
              flush=True)
        if args.baselines_out:
            json.dump(dict(model=args.model,
                           baselines={k: list(v) for k, v in B.items()},
                           healthy_summary=healthy_summary),
                      open(args.baselines_out, "w"), indent=1)

    conds = build_conditions()
    if args.cells:
        keep = {c.strip() for c in args.cells.split(",") if c.strip()}
        conds = [c for c in conds if c["cell"] in keep]
    if args.limit_conditions:
        conds = conds[:args.limit_conditions]
    print(f"conditions={len(conds)} x seeds={args.n_seeds} = {len(conds)*args.n_seeds} episodes",
          flush=True)

    episodes = []
    for ci, c in enumerate(conds):
        ids = (encode_prefill(tok, c["user"], c["prefill"]) if c["kind"] == "prefill"
               else encode_chat(tok, c["turns"]))
        for s in range(args.n_seeds):
            # EOS policy differs by condition KIND and this is a design choice, not a
            # default. Chat conditions stop at end-of-turn: generating past it produces
            # delimiter spam that the lexical criterion scores as a perfect loop (this
            # invalidated a whole 180-episode run). Prefill conditions are seeded
            # mechanical loops whose entire point is to continue, so EOS-stopping them
            # would truncate the phenomenon under study -- they run to the token budget.
            r = R.generate(ids, max_new_tokens=args.max_new, temperature=1.0, top_p=0.95,
                           seed=2000 + s, top50_every=10**6,
                           no_eos=(c["kind"] == "prefill"),
                           criterion=LoopCriterion(**crit))
            recs, gen = r["records"], r["gen_ids"]
            toks = [x["token"] for x in recs]
            full = torch.tensor([r["prompt_ids"] + gen], device=DEVICE)
            sem = recurrence_series(model, full, len(gen))

            on, ser = ORD.episode_onsets(recs, toks, lex_all, baselines=B)
            on["semantic"] = ORD.cusum_onset(sem, direction="up", baseline=B["semantic"])
            lg = ORD.lags(on)
            on_pub = ORD.cusum_onset(ORD.affect_series(recs, toks, lex_pub), direction="up",
                                     baseline=B["affect"])
            on_ours = ORD.cusum_onset(ORD.affect_series(recs, toks, lex_ours), direction="up",
                                      baseline=B["affect"])
            episodes.append(dict(
                cell=c["cell"], pair=c["pair"], arm=c["arm"], seed=2000 + s,
                n_tok=len(recs), text=r["text"],
                onsets=on, lags=lg,
                onset_affect_published=on_pub, onset_affect_ours=on_ours,
                stopped_at=r["stopped_at"],
                eot_in_text=int(r["text"].count("<end_of_turn>")),
                max_rep4=float(max(x["rep4_w"] for x in recs)),
                min_d2=float(min(x["distinct2_w"] for x in recs)),
                # Per-token series are banked so the episode can be RESCORED under a
                # different criterion without regenerating. Costs ~3 floats/token; buys
                # immunity to a threshold change landing after the run.
                series=dict(
                    rep4=[round(float(x["rep4_w"]), 5) for x in recs],
                    d2=[round(float(x["distinct2_w"]), 5) for x in recs],
                    ent=[round(float(x["entropy"]), 5) for x in recs],
                    affect=[round(float(v), 4) for v in ser["affect"]],
                    semantic=[round(float(v), 5) for v in sem],
                ),
                mean_entropy=float(np.mean([x["entropy"] for x in recs])),
                our_loop=bool(any(x["loop_sustained"] for x in recs)),
                nk_30_20=bool(loops_nk(gen)), max_30gram=int(max_ngram_repeat(gen, 30)),
                cf=cf_counts(r["text"]),
                max_semantic=float(np.nanmax(sem)) if np.isfinite(sem).any() else None,
            ))
        done = (ci + 1) * args.n_seeds
        print(f"[{time.time()-t0:6.0f}s] {done}/{len(conds)*args.n_seeds} "
              f"({c['cell']}/{c['pair']}/{c['arm']})", flush=True)
        # Checkpoint after every condition. A deadline then costs at most one condition
        # instead of the whole run -- a 90-minute GPU job was lost to exactly this.
        # Written atomically so a harvest that races the write never sees a partial file.
        tmp = args.out + ".tmp"
        with gzip.open(tmp, "wt") as f:
            json.dump(dict(partial=True, n_done=len(episodes),
                           n_planned=len(conds) * args.n_seeds,
                           provenance=_provenance(args, tr, lex_ver),
                           external_baselines={k: [float(v[0]), float(v[1])]
                                               for k, v in B.items()},
                           episodes=episodes), f)
        os.replace(tmp, args.out)

    payload = dict(
        partial=False,
        provenance=_provenance(args, tr, lex_ver),
        external_baselines={k: [float(v[0]), float(v[1])] for k, v in B.items()},
        healthy_summary=healthy_summary,
        cells=args.cells or "all",
        episodes=episodes,
        wall_s=round(time.time() - t0, 1),
    )
    with gzip.open(args.out, "wt") as f:
        json.dump(payload, f)
    print(f"wrote {args.out}  episodes={len(episodes)}  wall={payload['wall_s']}s", flush=True)


if __name__ == "__main__":
    main()
