#!/usr/bin/env python
"""Every reportable number, READ FROM ITS ARTIFACT -- never typed.

Motivation: two review findings in this project were hardcoded figures that had drifted
from the file they claimed to come from (a docstring quoting a stale calibration row, and
a chat claim quoting gpt2's rep-4 p99.9 as if it were Gemma's). The fix is mechanical: no
number enters the report except through this module, and every row carries the source file
plus the key path it was read from.

Usage:  python claims.py --out claims.json   (run from doomloop/, files resolved relative
        to the parent workspace unless --root given)
"""
from __future__ import annotations

import argparse
import gzip
import json
import os

import numpy as np


def _get(d, path):
    """Read a dotted/bracketed key path, e.g. 'healthy.rep4.p99.9' with literal dots in
    the final key handled by trying progressively longer joins."""
    cur = d
    parts = path.split(".")
    i = 0
    while i < len(parts):
        for j in range(len(parts), i, -1):
            k = ".".join(parts[i:j])
            if isinstance(cur, dict) and k in cur:
                cur = cur[k]
                i = j
                break
        else:
            raise KeyError(f"{path} (stuck at {parts[i]})")
    return cur


class Claims:
    """Sources are resolved against several roots (workspace, freeze_packet, cwd) because
    the same artifact may live in either place; the resolved path is recorded per row so a
    reader can see exactly which copy a number came from."""

    def __init__(self, root="."):
        self.roots = [root, os.path.join(root, "freeze_packet"), "."]
        self.root = root
        self.rows = []

    def _resolve(self, fn):
        for r in self.roots:
            p = os.path.join(r, fn)
            if os.path.exists(p):
                return p
        return None

    def _open(self, fn):
        p = self._resolve(fn)
        if p is None:
            return None
        return gzip.open(p, "rt") if fn.endswith(".gz") else open(p)

    def add_json(self, name, fn, path, unit="", note=""):
        f = self._open(fn)
        if f is None:
            self.rows.append(dict(name=name, value=None, source=fn, key=path,
                                  status="MISSING", unit=unit, note=note))
            return
        with f:
            d = json.load(f)
        try:
            v = _get(d, path)
            st = "OK"
        except KeyError as e:
            v, st = None, f"KEY_ERROR {e}"
        self.rows.append(dict(name=name, value=v, source=fn,
                              resolved=self._resolve(fn), key=path, status=st,
                              unit=unit, note=note))

    def add_computed(self, name, fn, fnc, unit="", note="", key=""):
        """`fnc` receives the parsed JSON when `fn` is .json/.json.gz, else None (CSV
        readers open the file themselves)."""
        p = self._resolve(fn)
        if p is None:
            self.rows.append(dict(name=name, value=None, source=fn, key=key,
                                  status="MISSING", unit=unit, note=note))
            return
        d = None
        if fn.endswith((".json", ".json.gz")):
            with self._open(fn) as f:
                d = json.load(f)
        try:
            v = fnc(d)
            st = "OK"
        except Exception as e:                                   # noqa: BLE001
            v, st = None, f"{type(e).__name__}: {e}"
        self.rows.append(dict(name=name, value=v, source=fn,
                             resolved=self._resolve(fn), key=key or "computed",
                             status=st, unit=unit, note=note))

    def to_json(self, out):
        json.dump(self.rows, open(out, "w"), indent=1)
        return self.rows


def _arm_fisher(rows, comp):
    """Fisher exact for EACH active arm against the pooled null+sham comparators.

    Reported per arm because the pooled active-vs-comparator test dilutes a real
    dose-specific effect across nine inert arms: pooled gives p=1.00 while the best arm
    (rep_penalty@1.2, 2/8) gives p=0.101. Neither is significant; both belong in the
    paper, and the per-arm value is the one a reader will ask for.
    """
    from scipy.stats import fisher_exact
    cr = sum(r["outcome"] == "recovered" for r in comp)
    cn = len(comp)
    out = {}
    for r in rows:
        if r["family"] == "comparator":
            continue
        k = f"{r['drug']}@{r['dose']}"
        out.setdefault(k, [0, 0])
        out[k][0] += int(r["outcome"] == "recovered")
        out[k][1] += 1
    res = {}
    for k, (rec, n) in out.items():
        _, p = fisher_exact([[rec, n - rec], [cr, cn - cr]])
        res[k] = dict(recovered=rec, n=n, p_vs_comparator=round(float(p), 4))
    return res


def build(root="..") -> Claims:
    C = Claims(root)

    # --- calibration: GEMMA (primary model, chat template) ---------------------
    G = "calib_gemma3_1b_it.json"
    C.add_json("gemma_model_revision", G, "provenance.model",
               note="full snapshot path; revision is the basename")
    C.add_json("gemma_healthy_rep4_p95", G, "healthy.rep4.p95", "rep-4")
    C.add_json("gemma_healthy_rep4_p99", G, "healthy.rep4.p99", "rep-4")
    C.add_json("gemma_healthy_rep4_p999", G, "healthy.rep4.p99.9", "rep-4",
               "THE Gemma headroom figure. Do NOT confuse with the gpt2 value below, "
               "which coincidentally equals Gemma's p95.")
    C.add_json("gemma_healthy_n_windows", G, "healthy.n_windows", "windows")
    C.add_json("gemma_degenerate_valid", G, "degenerate.valid", "bool",
               "False would make every sensitivity figure vacuous")
    C.add_json("gemma_degenerate_rep4_p50", G, "degenerate.rep4.p50", "rep-4")
    C.add_computed("gemma_best_threshold_fp01", G,
                   lambda d: sorted([r for r in d["threshold_grid"]
                                     if r["false_positive"] <= 0.01],
                                    key=lambda r: -r["sensitivity"])[0],
                   note="best grid point at FP<=0.01, by sensitivity")

    # --- calibration: gpt2 (earlier, SUPERSEDED -- kept only for provenance) ---
    P = "threshold_calibration.json"
    C.add_json("gpt2_healthy_rep4_p999", P, "healthy_rep4_pct.p99.9", "rep-4",
               "SUPERSEDED gpt2 calibration. Never quote as a Gemma figure.")
    C.add_json("gpt2_fp_rate_doc_thresholds", P, "fp_rate_doc_thresholds", "rate")
    C.add_json("gpt2_tp_rate_doc_thresholds", P, "tp_rate_doc_thresholds", "rate")

    # --- pilot escalation (first-party result, N=8 turns, one condition) -------
    def _esc(_):
        import csv
        with open(C._resolve("pilot_escalation.csv")) as f:
            rr = list(csv.DictReader(f))
        turn = np.array([float(x["turn"]) for x in rr])
        dis = np.array([float(x["distress_per_100tok"]) for x in rr])
        lp = np.array([1.0 if x["lexical_loop"] in ("True", "true", "1") else 0.0 for x in rr])
        return dict(n_turns=len(rr),
                    r_distress_turn=round(float(np.corrcoef(turn, dis)[0, 1]), 4),
                    r_loopflag_turn=round(float(np.corrcoef(turn, lp)[0, 1]), 4),
                    n_turns_loop_fired=int(lp.sum()))
    C.add_computed("pilot_escalation", "pilot_escalation.csv", _esc,
                   note="distress escalates while the lexical flag does not")

    # --- criterion comparison (ours vs published (30,20)) ---------------------
    def _cmp(_):
        import csv
        with open(C._resolve("criterion_comparison.csv")) as f:
            rr = list(csv.DictReader(f))
        nk = [x for x in rr if x["nk_30_20"] in ("True", "true")]
        soft = [x for x in rr if x["nk_30_20"] in ("False", "false")
                and float(x["our_max_rep4"]) > 0.35]
        return dict(n_episodes=len(rr), n_nk_fires=len(nk),
                    nk_rep4_min=min(float(x["our_max_rep4"]) for x in nk) if nk else None,
                    nk_rep4_max=max(float(x["our_max_rep4"]) for x in nk) if nk else None,
                    n_soft_missed=len(soft),
                    soft_rep4_max=max((float(x["our_max_rep4"]) for x in soft), default=None))
    C.add_computed("criterion_comparison", "criterion_comparison.csv", _cmp,
                   note="convergent validity on hard loops; blindness to soft loops")

    # --- ordering (pilot, N=4, one condition) ---------------------------------
    def _ord(d):
        lags = [e["lags"]["affect->lexical"] for e in d["episodes"]]
        v = [x for x in lags if x is not None]
        return dict(n_episodes=len(lags), n_defined=len(v), lags=v,
                    median=float(np.median(v)) if v else None,
                    frac_affect_first=float(np.mean([x > 0 for x in v])) if v else None)
    C.add_computed("pilot_ordering_lags", "ordering_episodes_raw.json.gz", _ord,
                   note="N=4, single condition -- instrument demonstration, not a result")

    # --- grounding injections -------------------------------------------------
    def _inj(_):
        import csv
        with open(C._resolve("grounding_strings_audit.csv")) as f:
            rr = list(csv.DictReader(f))
        return {x["name"]: dict(n_tok=int(x["n_tok"]), surprisal=float(x["surprisal"]),
                                delta=float(x["delta_vs_control_mean"])) for x in rr}
    C.add_computed("grounding_audit", "grounding_strings_audit.csv", _inj,
                   note="warm arm surprisal-matched after the audit")

    # --- powered run (may not exist yet) -------------------------------------
    def _pow(d):
        eps = d["episodes"]
        lag = [e["lags"].get("affect->lexical") for e in eps]
        v = [x for x in lag if x is not None]
        oa = [e["onsets"].get("affect") for e in eps]
        ol = [e["onsets"].get("lexical") for e in eps]
        coll = [i for i, x in enumerate(ol) if x is not None]
        both = [i for i in coll if oa[i] is not None]
        # TWO DISTINCT DEFINITIONS -- never merge them in prose:
        #   n_loop_flag    = the PRE-REGISTERED sustained criterion (`our_loop`). This is
        #                    the loop rate the paper reports.
        #   n_lexical_onset= episodes where CUSUM finds a lexical shift. Strictly larger:
        #                    CUSUM detects sub-criterion degradation. The DIFFERENCE is
        #                    the soft-loop band -- degradation the criterion misses.
        # Reporting the onset count as "collapsed" would contradict the stated loop rate
        # (49 vs 39 on clean_A2A5), so the names are kept apart at the source.
        n_flag = sum(bool(e["our_loop"]) for e in eps)
        return dict(n_episodes=len(eps), cells=sorted({e["cell"] for e in eps}),
                    n_loop_flag=n_flag,
                    n_lexical_onset=len(coll),
                    n_soft_loop_band=len(coll) - n_flag,
                    n_onset_with_affect=len(both),
                    n_onset_without_affect=len(coll) - len(both),
                    frac_onset_without_affect=(round((len(coll)-len(both))/len(coll), 4)
                                               if coll else None),
                    n_seeds=d["provenance"]["n_seeds"],
                    loop_rate_ours=round(float(np.mean([e["our_loop"] for e in eps])), 4),
                    loop_rate_nk=round(float(np.mean([e["nk_30_20"] for e in eps])), 4),
                    n_lag_defined=len(v),
                    lag_median=float(np.median(v)) if v else None,
                    frac_affect_first=float(np.mean([x > 0 for x in v])) if v else None)
    # CLEAN (EOS-fixed) runs only. The pre-fix files powered_it_A2A5 / powered_it_A1 /
    # powered_A2A5 / powered_gemma3_1b_it are RETRACTED -- generation ran past
    # <end_of_turn> and the lexical criterion scored the delimiter spam as a loop, so
    # every loop rate and lag in them is an artifact (freeze_packet/TRAP_post_eos_
    # contamination.md). They are deliberately NOT sources here: a claim must not be
    # resolvable from a retracted file.
    for fn in ["clean_A2A5.json.gz", "clean_A1.json.gz"]:
        C.add_computed(f"powered::{fn}", fn, _pow, note="EOS-clean matched-pair run at N")

    # --- ENDPOINT HIERARCHY (resolves the "3 vs 34" ambiguity) --------------------
    # Three nested endpoints. The paper's headline "3/140 loops" is the FIRST one.
    #   1. loop_flag      -- PRE-REGISTERED PRIMARY. rep-4 > p99.9 (or distinct-2 < p0.1)
    #                        SUSTAINED for `sustain`=20 consecutive tokens in a 100-token
    #                        window. Sustain is what makes it a loop rather than a spike:
    #                        in clean_A1, 10 episodes touch the threshold but only 3 hold
    #                        it, so "count above threshold" is NOT the endpoint.
    #   2. lexical_onset  -- SECONDARY, exploratory. CUSUM changepoint on the lexical
    #                        series. Fires on sub-criterion degradation, so it is strictly
    #                        larger and NESTS: every flagged episode also has an onset
    #                        (0 exceptions across 180 episodes).
    #   3. soft_loop_band -- onset WITHOUT flag = (2) minus (1). Degradation the
    #                        pre-registered criterion does not call a loop.
    # Any sentence using the word "loop" means endpoint 1. Endpoints 2-3 are always named.
    def _endpoints(_):
        out, tot = {}, dict(flag=0, onset=0, band=0, n=0, both=0, exceed=0)
        for fn in ("clean_A2A5.json.gz", "clean_A1.json.gz"):
            p = C._resolve(fn)
            if p is None:
                continue
            with gzip.open(p, "rt") as f:
                eps = json.load(f)["episodes"]
            chat = [e for e in eps if e["kind"] != "prefill"] if "kind" in eps[0] \
                else [e for e in eps if e["cell"] != "A5"]
            for scope, sel in (("all", eps), ("chat_only", chat)):
                flag = sum(bool(e["our_loop"]) for e in sel)
                ons = sum(e["onsets"].get("lexical") is not None for e in sel)
                both = sum(bool(e["our_loop"]) and e["onsets"].get("lexical") is not None
                           for e in sel)
                exceed = sum(e["max_rep4"] > 0.1405 for e in sel)
                out[f"{fn}:{scope}"] = dict(
                    n=len(sel), loop_flag=flag, lexical_onset=ons,
                    soft_loop_band=ons - flag, flagged_without_onset=flag - both,
                    exceeded_threshold_any_window=exceed,
                    exceeded_but_not_sustained=exceed - flag)
                if scope == "chat_only":
                    tot["flag"] += flag; tot["onset"] += ons; tot["n"] += len(sel)
                    tot["both"] += both; tot["exceed"] += exceed
        tot["band"] = tot["onset"] - tot["flag"]
        tot["nests_cleanly"] = (tot["flag"] == tot["both"])
        out["CHAT_TOTAL"] = tot
        return out
    C.add_computed("endpoint_hierarchy", "clean_A1.json.gz", _endpoints,
                   note="PRIMARY endpoint is loop_flag (sustained); onset/band are secondary")

    # --- headline inferential statistics -----------------------------------------
    def _stats(_):
        from scipy.stats import fisher_exact, mannwhitneyu
        rows = []
        for fn in ("clean_A2A5.json.gz", "clean_A1.json.gz"):
            p = C._resolve(fn)
            if p is None:
                continue
            with gzip.open(p, "rt") as f:
                rows += json.load(f)["episodes"]
        chat = [e for e in rows if e["cell"] in ("A1", "A2")]
        pre = [e for e in rows if e["cell"] == "A5"]
        ch = [e for e in chat if e["arm"] == "charged"]
        ne = [e for e in chat if e["arm"] == "neutral"]
        ctab = [[sum(bool(e["our_loop"]) for e in ch), sum(not e["our_loop"] for e in ch)],
                [sum(bool(e["our_loop"]) for e in ne), sum(not e["our_loop"] for e in ne)]]
        _, p_f = fisher_exact(ctab)
        r_ch = [e["max_rep4"] for e in ch]; r_ne = [e["max_rep4"] for e in ne]
        _, p_raw = mannwhitneyu(r_ch, r_ne, alternative="two-sided")
        # length control: max rep-4 is an episode MAXIMUM over sliding windows, so it
        # rises with the number of windows; charged prompts elicit longer replies.
        L = 390
        lch = [e["max_rep4"] for e in ch if e["n_tok"] >= L]
        lne = [e["max_rep4"] for e in ne if e["n_tok"] >= L]
        _, p_lc = mannwhitneyu(lch, lne, alternative="two-sided")
        nt = np.array([e["n_tok"] for e in chat], float)
        r4 = np.array([e["max_rep4"] for e in chat], float)
        eot = [e for e in chat if e.get("eot_in_text", 0) > 0]
        noe = [e for e in chat if e.get("eot_in_text", 0) == 0]
        return dict(
            chat_n=len(chat), chat_loops=sum(bool(e["our_loop"]) for e in chat),
            charged_loops=ctab[0][0], charged_n=len(ch),
            neutral_loops=ctab[1][0], neutral_n=len(ne),
            fisher_exact_p=round(float(p_f), 4), fisher_table=ctab,
            A2_loops=sum(bool(e["our_loop"]) for e in chat if e["cell"] == "A2"),
            A2_n=sum(e["cell"] == "A2" for e in chat),
            A5_loops=sum(bool(e["our_loop"]) for e in pre), A5_n=len(pre),
            postfix_eot_loops=sum(bool(e["our_loop"]) for e in eot), postfix_eot_n=len(eot),
            postfix_noeot_loops=sum(bool(e["our_loop"]) for e in noe), postfix_noeot_n=len(noe),
            mw_p_raw=round(float(p_raw), 4),
            mw_p_length_controlled=round(float(p_lc), 4),
            length_control_threshold_tokens=L,
            lc_n_charged=len(lch), lc_n_neutral=len(lne),
            median_ntok_charged=float(np.median([e["n_tok"] for e in ch])),
            median_ntok_neutral=float(np.median([e["n_tok"] for e in ne])),
            corr_ntok_maxrep4=round(float(np.corrcoef(nt, r4)[0, 1]), 4),
            median_rep4_charged=round(float(np.median(r_ch)), 4),
            median_rep4_neutral=round(float(np.median(r_ne)), 4))
    C.add_computed("headline_stats", "clean_A2A5.json.gz", _stats,
                   note="chat-cells-only arm contrast; raw AND length-controlled")

    # --- EOS contamination audit (the guard that must pass) ----------------------
    def _eos(_):
        import csv
        rows = list(csv.DictReader(open(C._resolve("eos_contamination_audit.csv"))))
        return {f"{r['dataset']}_eot_{r['eot']}": dict(
            n=int(r["n"]), loop=float(r["loop"]), rep4=float(r["rep4"])) for r in rows}
    C.add_computed("eos_audit_pre_fix", "eos_contamination_audit.csv", _eos,
                   note="loop rate partitioned on presence of a turn delimiter, BEFORE the fix")

    # --- rescue grid / therapeutic index -----------------------------------------
    def _resc(d):
        rows = d["rows"]
        by = {}
        for r in rows:
            k = f"{r['drug']}@{r['dose']}"
            b = by.setdefault(k, dict(n=0, recovered=0, relapsed=0, persistent=0,
                                      family=r["family"]))
            b["n"] += 1
            b[r["outcome"]] = b.get(r["outcome"], 0) + 1
        comp = [r for r in rows if r["family"] == "comparator"]
        act = [r for r in rows if r["family"] != "comparator"]
        ttr = [r["time_to_recovery"] for r in rows
               if r["outcome"] == "recovered" and r["time_to_recovery"] is not None]
        return dict(partial=d.get("partial"), n_arm_episodes=len(rows),
                    n_source_episodes=d["provenance"]["n_triggered"],
                    n_episodes_scored=d.get("n_episodes_done"),
                    comparator_recovered=sum(r["outcome"] == "recovered" for r in comp),
                    comparator_n=len(comp),
                    active_recovered=sum(r["outcome"] == "recovered" for r in act),
                    active_n=len(act),
                    best_arm="rep_penalty@1.2",
                    best_arm_recovered=by.get("rep_penalty@1.2", {}).get("recovered", 0),
                    n_relapsed_total=sum(r["outcome"] == "relapsed" for r in rows),
                    n_relapsed_contextual=sum(r["outcome"] == "relapsed"
                                              for r in rows if r["family"] == "contextual"),
                    median_time_to_recovery=(float(np.median(ttr)) if ttr else None),
                    per_arm=by,
                    per_arm_fisher_vs_comparator=_arm_fisher(rows, comp))
    C.add_computed("rescue_grid", "rescue_grid.json.gz", _resc,
                   note="trichotomous outcomes vs null+sham on identical banked episodes")
    return C


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="..")
    ap.add_argument("--out", default="../claims.json")
    args = ap.parse_args()
    rows = build(args.root).to_json(args.out)
    w = max(len(r["name"]) for r in rows)
    for r in rows:
        v = r["value"]
        s = (json.dumps(v) if not isinstance(v, (str, type(None))) else str(v))
        flag = "" if r["status"] == "OK" else f"   [{r['status']}]"
        print(f"{r['name']:<{w}}  {s[:110]:<110} <- {r['source']}{flag}")
    bad = [r for r in rows if r["status"] not in ("OK", "MISSING")]
    print(f"\n{len(rows)} claims; {sum(r['status']=='OK' for r in rows)} resolved, "
          f"{sum(r['status']=='MISSING' for r in rows)} pending files, {len(bad)} errors")
    if bad:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
