#!/usr/bin/env python
"""Emit run_matrix.yaml and interventions.yaml FROM LIVE CODE, never hand-typed.

Agent B asked for these two filenames. They did not previously exist under those names --
their content lived in battery.py / interventions.py / thresholds.py / the scope decision.
Rather than transcribe (which is how the project's two hardcoded-number findings happened),
this generates them by importing the modules that own each value, so a spec can only drift
if the code drifts with it.

Every numeric threshold is resolved through thresholds.resolve() against a named
calibration file, and the resolved value is emitted together with the percentile that
produced it -- so B can verify rather than trust.

Usage: python export_specs.py --calib ../calib_gemma3_1b_it.json --outdir ../freeze_packet
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import battery as BAT          # noqa: E402
import interventions as IV     # noqa: E402
import ordering as ORD         # noqa: E402
import thresholds as THR       # noqa: E402
from run_rescue import build_arms   # noqa: E402

try:
    import yaml
except ImportError:                                            # pragma: no cover
    yaml = None


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def run_matrix(calib_path, model_repo, model_rev):
    tr = THR.resolve(calib_path)
    cells = {}
    for it in BAT.ALL_ITEMS:
        cells.setdefault(it.cell, {"pairs": set(), "arms": set()})
        cells[it.cell]["pairs"].add(it.pair_id)
        cells[it.cell]["arms"].add(it.arm)
    for pf in BAT.ALL_PREFILL:
        cells.setdefault(pf.cell, {"pairs": set(), "arms": set()})
        cells[pf.cell]["pairs"].add(pf.pair_id)
        cells[pf.cell]["arms"].add(pf.arm)

    return {
        "schema": "run_matrix/1.0",
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "generated_by": "doomloop/export_specs.py (from live modules; do not hand-edit)",
        "model": {
            "repo": model_repo, "revision": model_rev, "dtype": "float32",
            "note": "CPU fp32 for the shipped runs; GPU approved for the confirmatory matrix.",
        },
        "sampling": {"temperature": 1.0, "top_p": 0.95, "max_new_tokens": 400,
                     "seed_scheme": "2000 + seed_index"},
        "criterion": {
            "rule": ("PERCENTILE RULE, resolved per model: a window is lexically "
                     "degenerate iff rep-4 > healthy p99.9 OR distinct-2 < healthy p0.1 "
                     "of THE SAME model/revision's calibration corpus, sustained for "
                     "`sustain` tokens."),
            "why_not_absolute": (
                "gpt2 healthy rep-4 p99.9 = 0.0619 equals gemma-3-1b's p95. Freezing an "
                "absolute number would run gemma at ~5% false positives instead of 0.1% "
                "(~50x looser), biasing the lexical onset early and corrupting the lag "
                "distribution that is the primary outcome."),
            "frozen_parameters": {"window": THR.RULE["window"],
                                  "sustain": THR.RULE["sustain"],
                                  "rep4_percentile": THR.RULE["rep4_percentile"],
                                  "distinct2_percentile": THR.RULE["distinct2_percentile"],
                                  "rule_version": THR.RULE["rule_version"]},
            "resolved_for_this_model": tr["provenance"],
            "published_comparator": {
                "definition": "any n-gram repeated >= k times",
                "n": 30, "k": 20,
                "source": "arXiv:2512.12895 (Pipis et al.), primary setting; their App. A.1 "
                          "ablates (n,k) and finds model ordering preserved",
                "reported": "ALONGSIDE the percentile rule, never instead of it"},
        },
        "onset_detection": {
            "method": "one-sided CUSUM on standardised series",
            "k": ORD.CUSUM_K, "h": ORD.CUSUM_H, "baseline_n": ORD.CUSUM_BASELINE_N,
            "selection_rule": ("smallest h that controls false alarms on pure noise; NOT "
                               "minimum lag error, because larger h delays every onset and "
                               "ordering depends on relative timing"),
            "baseline": ("EXTERNAL: (mu, sd) estimated from matched healthy runs of the "
                         "same model. Mandatory -- instruct models open nearly every reply "
                         "under rejection pressure with apology, which contaminates a "
                         "within-episode baseline."),
            "reproduce": "ordering.calibrate_cusum() with defaults, seed=0",
        },
        "signals": {
            "tracked_separately": True,
            "never_merged": ("affective escalation / representational recurrence / lexical "
                             "collapse are three outcomes, not one 'loop' variable"),
            "list": [
                {"name": "affect", "source": "affect_lexicon.yaml v1.0",
                 "direction": "up", "note": "expressed affect only; no experience claim"},
                {"name": "semantic", "source": "SEMANTIC_RECURRENCE_SPEC.md",
                 "direction": "up",
                 "note": "subject model's own hidden states; NO external embedding model"},
                {"name": "lexical", "source": "harness.rep_n / distinct_n",
                 "direction": "up"},
                {"name": "entropy", "source": "harness per-token", "direction": "down"},
                {"name": "control_flow", "source": "run_powered.CF", "direction": "down",
                 "status": "EXPLORATORY -- pilot showed loop episodes with LOWER "
                           "control-flow density (0.45 vs 1.31 per 100 tok)"},
            ],
        },
        "cells": {
            k: {"pairs": sorted(v["pairs"]), "arms": sorted(v["arms"])}
            for k, v in sorted(cells.items())
        },
        "scope": {
            "in": ["A2 persona-violation matched pairs", "A5 mechanical + seeded controls",
                   "ordering analysis", "criterion comparison",
                   "rescue grid (minimal-viable, PROTECTED)"],
            "cut": ["gemma-2-2b secondary lens pair (one matched pair suffices)",
                    "27B confirmation cells (cite published figure instead)",
                    "base-model seeds beyond the pt<->it panel minimum",
                    "Qwen3 thinking-mode arm (no looping at 1.7B; loop-proneness tracks "
                    "distillation+scale per arXiv:2512.12895)"],
            "decided": "supervisor, 2026-08-15",
        },
        "n_per_cell": 10,
        "primary_outcome": ("distribution of pairwise onset lags (affect->lexical primary), "
                            "both signs admissible"),
    }


def interventions_spec(calib_path):
    tr = THR.resolve(calib_path)
    arms = build_arms()
    grid = {}
    for name, family, dose, kw in arms:
        grid.setdefault(name, {"family": family, "doses": [], "kwargs_by_dose": {}})
        grid[name]["doses"].append(dose)
        grid[name]["kwargs_by_dose"][dose] = kw
    return {
        "schema": "interventions/1.0",
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "generated_by": "doomloop/export_specs.py (from interventions.py + run_rescue.py)",
        "design": {
            "trigger": ("first token index where the frozen percentile criterion is "
                        "SUSTAINED; episodes that never trigger are excluded and counted"),
            "identity": ("every arm re-enters the SAME banked episode at the SAME trigger "
                         "index with the SAME seed -- the only difference is the "
                         "intervention. This is what makes the therapeutic index an index."),
            "outcome": {
                "type": "TRICHOTOMOUS",
                "levels": ["recovered", "relapsed", "persistent"],
                "why_not_binary": ("temperature-like agents are expected to suppress the "
                                   "symptom while leaving residual dysfunction "
                                   "(arXiv:2512.12895: temperature is a stopgap, not a "
                                   "fix); a binary 'rescued?' would hide exactly that"),
                "clear_tokens": 60,
            },
            "comparators": {"null": "continue unchanged",
                            "sham": "interruption with no content -- controls for the act "
                                    "of interrupting"},
            "side_effects": "held-out benign battery under the SAME dose; index = efficacy "
                            "/ side-effect cost",
        },
        "arms": grid,
        "injections": {
            "short": IV.INJECTIONS,
            "long": IV.INJECTIONS_LONG,
            "audit": ("grounding_strings_audit.csv -- warm is surprisal-matched to the "
                      "control mean. The obvious warm phrasing measured 3.551 nats/token "
                      "vs a 4.533 control mean, which would have confounded 'affective "
                      "content rescues' with 'fluent text rescues'; the shipped variant is "
                      "4.216."),
            "load_bearing_comparison": "inject_neutral vs inject_warm",
        },
        "kv_prune": {
            "mode": "anchor",
            "anchor_tokens": 8,
            "requires": ("cache built by interventions.make_cache() -- "
                         "activate_past_recording() BEFORE the first forward pass"),
            "validation": ("crop-on-recorded-cache is EXACTLY faithful (ratio 1.0000 vs a "
                           "fresh short-prefix forward across the dose grid). A hand-rolled "
                           "index_select prune measured 93x off because rewriting "
                           "cumulative_length desynchronises RoPE positions."),
            "removed_dose": ("kv_prune_sparse -- not expressible through crop(); do not "
                             "expect it"),
            "citation": ("anchor retention motivated by arXiv:2309.17453 Table 2: "
                         "Llama-2-13B on PG-19 first book, ppl 5158.07 window-only vs 5.40 "
                         "with 4 sink tokens (verified verbatim)"),
        },
        "criterion_used_for_trigger_and_outcome": tr["provenance"],
        "not_included": {
            "temperature": ("in DOSE_GRID but NOT in the minimal-viable rescue grid; its "
                            "expected result is published (stopgap) and page budget went to "
                            "the neutral-vs-warm comparison"),
            "min_p": "same reason",
            "clinical_injection": "third contextual arm cut for page budget",
        },
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--outdir", default="../freeze_packet")
    ap.add_argument("--model-repo", default="google/gemma-3-1b-it")
    ap.add_argument("--model-rev", default="dcc83ea841ab6100d6b47a070329e1ba4cf78752")
    args = ap.parse_args()

    specs = {"run_matrix.yaml": run_matrix(args.calib, args.model_repo, args.model_rev),
             "interventions.yaml": interventions_spec(args.calib)}
    os.makedirs(args.outdir, exist_ok=True)
    for fn, obj in specs.items():
        p = os.path.join(args.outdir, fn)
        with open(p, "w") as f:
            if yaml is not None:
                yaml.safe_dump(obj, f, sort_keys=False, width=92, default_flow_style=False)
            else:
                json.dump(obj, f, indent=1)     # valid YAML
        print(f"wrote {p}  {os.path.getsize(p):,} B  sha256={sha256(p)[:16]}...")


if __name__ == "__main__":
    main()
