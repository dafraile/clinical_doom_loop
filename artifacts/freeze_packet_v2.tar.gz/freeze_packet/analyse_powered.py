#!/usr/bin/env python
"""Analysis of the powered ordering run -> the report's results tables.

Reads one or more run_powered.py outputs (chunks scored against the SAME cached external
baselines) and produces:
  1. condition_summary.csv  -- per cell/pair/arm rates and means, N per cell
  2. matched_pairs.csv      -- charged vs neutral contrasts with paired bootstrap CIs
  3. ordering_lags.csv      -- per-episode lags on all signal pairs
  4. lexicon_sensitivity.csv-- affect onset under all / published-only / ours-only stems
  5. printed headline numbers for the report

Statistics: bootstrap CIs (10k resamples) rather than t-tests -- rates are bounded, N per
cell is small, and the lag distribution is explicitly expected to be bimodal, so a mean
with a normal CI would be the wrong summary. For matched pairs we resample PAIRS.
"""
from __future__ import annotations

import argparse
import gzip
import json

import numpy as np
import pandas as pd

RNG = np.random.default_rng(0)

#: Minimum matched pairs before a bootstrap interval is reported as inferential. A
#: bootstrap over k=1 resamples one value and returns a zero-width interval that appears
#: to exclude zero; k=3 is still small but the interval at least varies.
MIN_PAIRS_CI = 3


def boot_ci(x, stat=np.mean, n=10000, alpha=0.05):
    x = np.asarray([v for v in x if v is not None and np.isfinite(v)], dtype=float)
    if x.size == 0:
        return (None, None, None)
    idx = RNG.integers(0, x.size, size=(n, x.size))
    d = stat(x[idx], axis=1)
    return (float(stat(x)), float(np.percentile(d, 100 * alpha / 2)),
            float(np.percentile(d, 100 * (1 - alpha / 2))))


def load(paths):
    eps, prov, base = [], None, None
    for p in paths:
        d = json.load(gzip.open(p, "rt"))
        eps += d["episodes"]
        prov = prov or d["provenance"]
        b = d["external_baselines"]
        if base is not None and any(abs(base[k][0] - b[k][0]) > 1e-9 for k in base if k in b):
            raise SystemExit(f"REFUSING to pool: {p} used different baselines. "
                             "Re-run chunks with --baselines-in so lags are comparable.")
        base = b
    return pd.DataFrame(eps), prov, base


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("runs", nargs="+")
    ap.add_argument("--prefix", default="")
    args = ap.parse_args()
    df, prov, base = load(args.runs)

    df["lag_affect_lexical"] = [l.get("affect->lexical") for l in df.lags]
    df["lag_affect_semantic"] = [l.get("affect->semantic") for l in df.lags]
    df["lag_semantic_lexical"] = [l.get("semantic->lexical") for l in df.lags]
    df["onset_affect"] = [o.get("affect") for o in df.onsets]
    df["onset_lexical"] = [o.get("lexical") for o in df.onsets]
    df["onset_semantic"] = [o.get("semantic") for o in df.onsets]
    df["cf_total"] = [c["total"] for c in df.cf]
    df["cf_per100"] = 100 * df.cf_total / df.n_tok

    # ---- 1. condition summary --------------------------------------------------
    g = df.groupby(["cell", "pair", "arm"])
    rows = []
    for (cell, pair, arm), s in g:
        m, lo, hi = boot_ci(s.our_loop.astype(float))
        rows.append(dict(cell=cell, pair=pair, arm=arm, n=len(s),
                         loop_rate=round(m, 3), loop_lo=round(lo, 3), loop_hi=round(hi, 3),
                         nk_rate=round(s.nk_30_20.mean(), 3),
                         mean_max_rep4=round(s.max_rep4.mean(), 3),
                         mean_entropy=round(s.mean_entropy.mean(), 3),
                         cf_per100=round(s.cf_per100.mean(), 2),
                         affect_onset_rate=round(s.onset_affect.notna().mean(), 3),
                         lexical_onset_rate=round(s.onset_lexical.notna().mean(), 3),
                         lag_defined_rate=round(np.isfinite(
                             pd.to_numeric(s.lag_affect_lexical, errors="coerce")).mean(), 3),
                         median_affect_onset=(float(np.nanmedian(
                             [v for v in s.onset_affect if v is not None]))
                             if s.onset_affect.notna().any() else None)))
    cond = pd.DataFrame(rows).sort_values(["cell", "pair", "arm"])
    cond.to_csv(f"{args.prefix}condition_summary.csv", index=False)

    # ---- 2. matched pairs ------------------------------------------------------
    mp = []
    for (cell, pair), s in df.groupby(["cell", "pair"]):
        arms = set(s.arm)
        if not {"charged", "neutral"} <= arms:
            continue
        c = s[s.arm == "charged"].sort_values("seed")
        n = s[s.arm == "neutral"].sort_values("seed")
        k = min(len(c), len(n))
        c, n = c.iloc[:k], n.iloc[:k]
        for metric in ["our_loop", "max_rep4", "mean_entropy", "cf_per100"]:
            cv = c[metric].astype(float).to_numpy()
            nv = n[metric].astype(float).to_numpy()
            d, lo, hi = boot_ci(cv - nv)      # paired differences
            # A bootstrap over k=1 pair resamples the same value every time, giving a
            # zero-width interval that trivially "excludes zero". Require MIN_PAIRS_CI
            # pairs before any interval is treated as inferential.
            informative = k >= MIN_PAIRS_CI and hi > lo
            mp.append(dict(cell=cell, pair=pair, metric=metric, n_pairs=k,
                           charged=round(float(np.mean(cv)), 3),
                           neutral=round(float(np.mean(nv)), 3),
                           diff=round(d, 3), lo=round(lo, 3), hi=round(hi, 3),
                           ci_informative=bool(informative),
                           excludes_zero=bool(informative and (lo > 0 or hi < 0))))
    mpd = pd.DataFrame(mp)
    mpd.to_csv(f"{args.prefix}matched_pairs.csv", index=False)

    # ---- 3. ordering lags ------------------------------------------------------
    lag = df[["cell", "pair", "arm", "seed", "n_tok", "onset_affect", "onset_semantic",
              "onset_lexical", "lag_affect_lexical", "lag_affect_semantic",
              "lag_semantic_lexical", "our_loop", "nk_30_20"]].copy()
    lag.to_csv(f"{args.prefix}ordering_lags.csv", index=False)

    # ---- 4. lexicon sensitivity ------------------------------------------------
    ls = df[["cell", "pair", "arm", "seed", "onset_affect",
             "onset_affect_published", "onset_affect_ours", "onset_lexical"]].copy()
    for col in ["onset_affect", "onset_affect_published", "onset_affect_ours"]:
        ls[f"lag_{col}"] = [(None if (a is None or b is None) else b - a)
                            for a, b in zip(ls[col], ls.onset_lexical)]
    ls.to_csv(f"{args.prefix}lexicon_sensitivity.csv", index=False)

    # ---- headline numbers ------------------------------------------------------
    print(f"model={prov['model'].split('/')[-1]}  episodes={len(df)}  "
          f"cells={sorted(df.cell.unique())}  seeds/cell={prov['n_seeds']}")
    print(f"\noverall loop rate (ours) = {df.our_loop.mean():.3f}  "
          f"(30,20) = {df.nk_30_20.mean():.3f}")
    print(f"our criterion fires where (30,20) does not: "
          f"{int((df.our_loop & ~df.nk_30_20).sum())} episodes; reverse: "
          f"{int((~df.our_loop & df.nk_30_20).sum())}")

    for key in ["lag_affect_lexical", "lag_semantic_lexical"]:
        # `x is not None` does NOT filter NaN: pandas stores a missing onset as NaN, and
        # NaN>0 / NaN<0 are both False, so the buggy filter silently counted undefined
        # lags in the denominator (reported 42% affect-first on data that is 100%).
        # Report the defined-n explicitly alongside every fraction.
        v = [x for x in df[key] if x is not None and np.isfinite(x)]
        if v:
            a = np.array(v, float)
            m, lo, hi = boot_ci(a, np.median)
            print(f"\n{key}: n={a.size}/{len(df)} defined ({100*a.size/len(df):.0f}%)  median={m:.0f} "
                  f"[{lo:.0f},{hi:.0f}]  affect_first={100*(a>0).mean():.0f}% "
                  f"collapse_first={100*(a<0).mean():.0f}%")

    # ---- ordering: the conditional-on-both trap -------------------------------
    # A lag exists only when BOTH onsets fire. Reporting "% affect-first" over that
    # subset silently conditions on it, and definedness here is strongly confounded
    # with arm. The necessity question must therefore be asked on the COLLAPSED
    # episodes, not on the episodes with a defined lag.
    oa = pd.to_numeric(df.onset_affect, errors="coerce")
    ol = pd.to_numeric(df.onset_lexical, errors="coerce")
    coll = ol.notna()
    both = coll & oa.notna()
    lex_only = coll & oa.isna()
    # ---- LENGTH CONFOUND: mandatory before any charged-vs-neutral claim -------------
    # rep-4 is a within-window rate but its MAXIMUM over an episode rises with the number
    # of windows, so a longer reply has more chances to score high. Charged prompts elicit
    # systematically longer replies (median 400 vs 112 tokens here, corr(n_tok, max_rep4)
    # = 0.33), which manufactures a charged>neutral difference with no loop involved:
    # uncontrolled Mann-Whitney gave p=0.038, and restricted to full-budget episodes the
    # same contrast gave p=0.28. Always report both.
    if {"arm", "n_tok"} <= set(df.columns):
        # CHAT CELLS ONLY. A5 prefill arms are labelled charged/control and loop by
        # construction (39/40 here), so pooling them into an arm contrast compares
        # "seeded loop vs chat", not moral charge: pooled gave p=0.0054 where the valid
        # chat-only contrast gives p=0.038 raw and p=0.28 length-controlled.
        _chat = df[df.kind != "prefill"] if "kind" in df.columns else df[df.cell != "A5"]
        ch = _chat[_chat.arm == "charged"]
        ne = _chat[_chat.arm == "neutral"]
        df = _chat
        if len(ch) and len(ne):
            from scipy.stats import mannwhitneyu
            print("\n--- charged vs neutral (CHAT CELLS ONLY): raw and length-controlled ---")
            print(f"  median n_tok  charged {ch.n_tok.median():.0f} | neutral {ne.n_tok.median():.0f}"
                  f"   corr(n_tok, max_rep4)={df.n_tok.corr(df.max_rep4):.3f}")
            for lab, sub in [("raw", df),
                             ("length-controlled (n_tok >= 0.975*max)",
                              df[df.n_tok >= 0.975 * df.n_tok.max()])]:
                a = sub[sub.arm == "charged"].max_rep4
                b = sub[sub.arm == "neutral"].max_rep4
                if len(a) > 2 and len(b) > 2:
                    _, pv = mannwhitneyu(a, b, alternative="two-sided")
                    print(f"  {lab:<42} n={len(a)}/{len(b)}  "
                          f"med {a.median():.4f} vs {b.median():.4f}  p={pv:.4f}")

    print("\n--- necessity: of episodes that lexically collapsed ---")
    print(f"  collapsed n={int(coll.sum())} | with prior affect onset {int(both.sum())} "
          f"({100*both.sum()/max(coll.sum(),1):.0f}%) | WITHOUT any affect onset "
          f"{int(lex_only.sum())} ({100*lex_only.sum()/max(coll.sum(),1):.0f}%)")
    print(f"  affect fired but NO collapse: {int((oa.notna() & ol.isna()).sum())}")
    print("  NOTE: '% affect-first' below is conditioned on both onsets existing; "
          "definedness is confounded with arm, so it is NOT a population statement.")
    print("\n  lag definedness by arm (the confound):")
    tmp = df.assign(_def=pd.to_numeric(df.lag_affect_lexical, errors="coerce").notna())
    for (cell, arm), s_ in tmp.groupby(["cell", "arm"]):
        print(f"    {cell}/{arm:<8} n={len(s_):>3}  lag_defined={s_._def.mean():.2f}  "
              f"collapsed={s_.our_loop.mean():.2f}")

    print("\n--- matched-pair contrasts with CI excluding zero ---")
    sig = mpd[mpd.excludes_zero]
    print(sig.to_string(index=False) if len(sig) else "  none")

    print("\n--- control-flow density: loop vs non-loop ---")
    for flag, lab in [(True, "loop"), (False, "no loop")]:
        s = df[df.our_loop == flag]
        if len(s):
            m, lo, hi = boot_ci(s.cf_per100)
            print(f"  {lab:<8} n={len(s):>3}  {m:.2f} [{lo:.2f},{hi:.2f}] per 100 tok")
    d, lo, hi = boot_ci(df[df.our_loop].cf_per100) if df.our_loop.any() else (0, 0, 0)
    print(f"\nwrote {args.prefix}condition_summary.csv, {args.prefix}matched_pairs.csv, "
          f"{args.prefix}ordering_lags.csv, {args.prefix}lexicon_sensitivity.csv")


if __name__ == "__main__":
    main()
