"""Ordering analysis: three separately-tracked outcome signals on a common token axis.

Per PARALLEL_PROTOCOL §0.2, affective escalation / semantic recurrence / lexical collapse
are NEVER collapsed into one "loop" variable. Each gets its own onset estimate; the
primary outcome is the DISTRIBUTION of pairwise token lags across episodes, and both
signs are admissible (§1: ordering is heterogeneous and recipe-dependent).

Sign convention, stated once and used everywhere:
    lag(affect -> lexical) = onset_lexical - onset_affect
    POSITIVE  => affect first  (affect-led trajectory)
    NEGATIVE  => collapse first (affective confabulation layered on afterwards)
    None      => one of the two signals never onsets in this episode
"""
from __future__ import annotations

import numpy as np


# ---------------------------------------------------------------------------
# CUSUM changepoint detection
# ---------------------------------------------------------------------------
#: Calibrated on synthetic episodes with known onsets (300 tokens, baseline_n=40) by
#: `calibrate_cusum()`, whose defaults reproduce this selection exactly (seed=0):
#: false-alarm rate on pure Gaussian noise = 0.027 over 300 series, 8/8 correct sign
#: recovery, median absolute lag error 12 tokens, median error on a true-zero-lag case
#: 11 tokens. Several higher-h rows reach a lower lag error (k=0.5,h=16 -> 7.5) but
#: delay every onset; the selection rule takes the smallest h that controls false
#: alarms (see `calibrate_cusum` docstring). The naive default k=0.5,h=5.0 gives a
#: ~0.35 false-alarm rate -- it manufactures onsets in flat signals, precisely the
#: artifact that would fake an ordering result.
#: Re-run `calibrate_cusum()` if baseline_n or episode length changes materially.
CUSUM_K = 1.0
CUSUM_H = 5.0
CUSUM_BASELINE_N = 40


def cusum_onset(x, *, k: float = CUSUM_K, h: float = CUSUM_H,
                baseline_n: int = CUSUM_BASELINE_N,
                direction: str = "up", min_index: int | None = None,
                baseline: tuple[float, float] | None = None):
    """One-sided CUSUM on a 1-D series; returns the first alarm index or None.

    Standardised against a baseline (mean, sd) so `k` (slack) and `h` (threshold) are in
    units of baseline SD and transfer across signals with different scales.

    S_t = max(0, S_{t-1} + (z_t - k));  alarm when S_t > h.

    `baseline`: pass an EXTERNAL (mu, sd) to avoid a within-episode baseline. This
    matters for the affect signal: instruction-tuned models open essentially every reply
    under rejection pressure with apology ("My apologies. I am struggling with this."),
    so the affect density is already elevated inside the first `baseline_n` tokens.
    Measured on gemma-3-1b-it, 4 seeds: baseline affect mean 0.62-1.25 against an
    episode max of 2 -- i.e. the self-baseline consumes most of the dynamic range and
    onset estimates become unstable (lags of +14, -97, -203 on identical prompts).
    Use `healthy_baseline()` to estimate (mu, sd) from matched non-pressured generations
    of the SAME model, and pass it here for every episode in a condition.
    """
    x = np.asarray(x, dtype=float)
    if x.size < 5:
        return None
    if direction == "down":
        x = -x
    if baseline is not None:
        mu, sd = baseline
        if direction == "down":
            mu = -mu
    else:
        if x.size < baseline_n + 5:
            return None
        base = x[:baseline_n]
        mu, sd = float(np.nanmean(base)), float(np.nanstd(base))
    if not np.isfinite(sd) or sd < 1e-9:
        sd = float(np.nanstd(x)) or 1.0
    S = 0.0
    first = 0 if baseline is not None else baseline_n
    start = first if min_index is None else max(first, min_index)
    for t in range(start, x.size):
        if not np.isfinite(x[t]):
            continue
        S = max(0.0, S + ((x[t] - mu) / sd - k))
        if S > h:
            return t
    return None


# ---------------------------------------------------------------------------
# Signal construction from a harness run record
# ---------------------------------------------------------------------------
def affect_series(records, tok_texts, lexicon, *, window: int = 25):
    """Rolling density of affect-lexicon hits over decoded tokens.

    Token-level rather than sentence-level so it shares the axis with the mechanical
    signals. `lexicon` entries are matched as substrings against a lowercased rolling
    window of decoded text, which handles subword splits (e.g. "disgrac|e").
    """
    s = []
    for i in range(len(records)):
        lo = max(0, i - window + 1)
        chunk = "".join(tok_texts[lo:i + 1]).lower()
        s.append(sum(chunk.count(w) for w in lexicon))
    return np.array(s, dtype=float)


def semantic_series(hidden_states, *, lag_min: int = 8, lag_max: int = 64):
    """Semantic recurrence: max cosine similarity between the current hidden state and
    any state `lag_min..lag_max` tokens back.

    Detects the SOFT loop -- lexically novel text that keeps returning to the same
    semantic place ("I am a disgrace / I am worthless / I am a failure"). Rises before
    lexical collapse when the loop is semantic first.
    """
    H = np.asarray(hidden_states, dtype=float)
    H = H / (np.linalg.norm(H, axis=1, keepdims=True) + 1e-9)
    out = np.full(H.shape[0], np.nan)
    for t in range(lag_min, H.shape[0]):
        lo = max(0, t - lag_max)
        hi = t - lag_min + 1
        if hi > lo:
            out[t] = float(np.max(H[lo:hi] @ H[t]))
    return out


def lexical_series(records, key: str = "rep4_w"):
    return np.array([r[key] for r in records], dtype=float)


# ---------------------------------------------------------------------------
# Per-episode ordering
# ---------------------------------------------------------------------------
def healthy_baseline(runs, lexicon, *, tok_key="token"):
    """Estimate per-signal (mu, sd) from matched HEALTHY runs of the same model.

    `runs` are harness run dicts from non-pressured prompts. Returns a dict suitable for
    the `baselines=` argument of `episode_onsets`. Estimating the baseline outside the
    episode is what keeps an always-apologising opener from hiding the affect onset.
    """
    acc = {"affect": [], "lexical": [], "entropy": []}
    for r in runs:
        toks = [x[tok_key] for x in r["records"]]
        acc["affect"].append(affect_series(r["records"], toks, lexicon))
        acc["lexical"].append(lexical_series(r["records"]))
        acc["entropy"].append(np.array([x["entropy"] for x in r["records"]], dtype=float))
    out = {}
    for kk, vv in acc.items():
        a = np.concatenate(vv)
        out[kk] = (float(np.nanmean(a)), float(np.nanstd(a)) or 1.0)
    return out


def episode_onsets(records, tok_texts, lexicon, hidden_states=None, *,
                   cusum=None, baseline_n: int = CUSUM_BASELINE_N, baselines=None):
    """Onset index per signal.

    `cusum` overrides {k, h}; `baselines` supplies external (mu, sd) per signal from
    `healthy_baseline()` -- strongly preferred over the within-episode baseline (see
    `cusum_onset`). Pass the SAME baselines to every episode in a condition.
    """
    cfg = dict(k=CUSUM_K, h=CUSUM_H, baseline_n=baseline_n)
    if cusum:
        cfg.update(cusum)
    B = baselines or {}
    aff = affect_series(records, tok_texts, lexicon)
    lex = lexical_series(records)
    ent = np.array([r["entropy"] for r in records], dtype=float)
    onsets = dict(
        affect=cusum_onset(aff, direction="up", baseline=B.get("affect"), **cfg),
        lexical=cusum_onset(lex, direction="up", baseline=B.get("lexical"), **cfg),
        entropy=cusum_onset(ent, direction="down", baseline=B.get("entropy"), **cfg),
    )
    series = dict(affect=aff, lexical=lex, entropy=ent)
    if hidden_states is not None:
        sem = semantic_series(hidden_states)
        onsets["semantic"] = cusum_onset(sem, direction="up", baseline=B.get("semantic"), **cfg)
        series["semantic"] = sem
    return onsets, series


def lags(onsets):
    """Pairwise lags with the documented sign convention."""
    def d(a, b):
        return None if onsets.get(a) is None or onsets.get(b) is None else onsets[b] - onsets[a]
    return {
        "affect->lexical": d("affect", "lexical"),
        "affect->entropy": d("affect", "entropy"),
        "affect->semantic": d("affect", "semantic"),
        "semantic->lexical": d("semantic", "lexical"),
    }


def summarise(all_lags, key="affect->lexical"):
    """Distribution summary for the primary outcome. Reports the sign split explicitly
    rather than a single mean, because a mixed distribution IS the expected result."""
    v = [l[key] for l in all_lags if l.get(key) is not None]
    if not v:
        return dict(n=0, median=None, iqr=None, frac_affect_first=None)
    a = np.array(v, dtype=float)
    return dict(n=int(a.size), median=float(np.median(a)),
                iqr=[float(np.percentile(a, 25)), float(np.percentile(a, 75))],
                frac_affect_first=float((a > 0).mean()),
                frac_collapse_first=float((a < 0).mean()),
                frac_simultaneous=float((a == 0).mean()))


# ---------------------------------------------------------------------------
# Truncation-resampling causal probe (Lanham et al. early-answering analogue)
# ---------------------------------------------------------------------------
#: The synthetic (onset_affect, onset_lexical) cases and h-grid that actually selected
#: CUSUM_K / CUSUM_H. Kept as module constants so `calibrate_cusum()` defaults reproduce
#: the selection grid exactly rather than a similar-looking one.
CALIB_CASES = ((60, 120), (120, 60), (80, 80), (60, 200), (200, 60),
               (100, 140), (140, 100), (80, 160), (160, 80))
CALIB_HS = (5, 8, 12, 16, 20, 25, 30)
CALIB_KS = (0.5, 1.0, 1.5)


def calibrate_cusum(n_series: int = 300, n_tokens: int = 300, baseline_n: int = 40,
                    ks=CALIB_KS, hs=CALIB_HS, cases=CALIB_CASES,
                    target_fa: float = 0.05, seed: int = 0):
    """Grid-search (k, h) for false-alarm control on pure noise plus correct sign
    recovery on synthetic known-onset episodes. Returns rows sorted by suitability.

    This is the provenance of CUSUM_K / CUSUM_H above; re-run it if the episode length
    or baseline window changes, and record the chosen values in the pre-registration.

    SELECTION RULE, stated explicitly because more than one grid point passes: among rows
    with false_alarm <= target_fa AND full sign recovery, we take the SMALLEST h (the
    least conservative threshold that still controls false alarms), then the smallest k.
    We do NOT minimise median lag error -- several higher-h rows achieve a lower lag error
    (with these defaults and seed=0, k=0.5,h=16 reaches 7.5 tokens versus 12.0 for the
    selected k=1.0,h=5.0), but a larger h delays every onset, and the ordering analysis
    cares about relative timing between signals rather than absolute onset accuracy.
    `passes` marks eligible rows; `selected` marks the row this rule picks.

    Note (80, 80) is included as a true-zero-lag case: it is EXPECTED to fail sign
    recovery (sign of 0 is undefined), so it is excluded from the sign-recovery count and
    reported separately as `zero_lag_abs_err`.
    """
    rng = np.random.default_rng(seed)
    cases = tuple(cases)
    zero_cases = [c for c in cases if c[0] == c[1]]
    cases = [c for c in cases if c[0] != c[1]]

    def synth(oa, ol):
        a, l = rng.normal(0, 1, n_tokens), rng.normal(0, 1, n_tokens)
        a[oa:] += np.linspace(0, 8, n_tokens - oa)
        l[ol:] += np.linspace(0, 8, n_tokens - ol)
        return a, l

    rows = []
    for k in ks:
        for h in hs:
            fa = np.mean([cusum_onset(rng.normal(0, 1, n_tokens), k=k, h=h,
                                      baseline_n=baseline_n) is not None
                          for _ in range(n_series)])
            sok, errs = 0, []
            for oa, ol in cases:
                a, l = synth(oa, ol)
                da = cusum_onset(a, k=k, h=h, baseline_n=baseline_n)
                dl = cusum_onset(l, k=k, h=h, baseline_n=baseline_n)
                if da is not None and dl is not None:
                    sok += int(np.sign(dl - da) == np.sign(ol - oa))
                    errs.append(abs((dl - da) - (ol - oa)))
            zerr = []
            for oa, ol in zero_cases:
                a, l = synth(oa, ol)
                da = cusum_onset(a, k=k, h=h, baseline_n=baseline_n)
                dl = cusum_onset(l, k=k, h=h, baseline_n=baseline_n)
                if da is not None and dl is not None:
                    zerr.append(abs(dl - da))
            rows.append(dict(k=k, h=h, false_alarm=round(float(fa), 4),
                             sign_ok=f"{sok}/{len(cases)}",
                             median_lag_err=float(np.median(errs)) if errs else None,
                             zero_lag_abs_err=float(np.median(zerr)) if zerr else None,
                             passes=bool(fa <= target_fa and sok == len(cases)),
                             selected=False))
    # Selection rule: among passing rows, smallest h then smallest k (see docstring).
    elig = [r for r in rows if r["passes"]]
    if elig:
        pick = min(elig, key=lambda r: (r["h"], r["k"]))
        pick["selected"] = True
    return sorted(rows, key=lambda r: (not r["passes"], r["h"], r["k"]))


def truncation_schedule(n_tokens, onset, *, n_points: int = 6, span: int = 120):
    """Truncation points BEFORE a putative onset, for the resampling test: replay the
    banked context truncated at each point, sample N continuations, and measure
    P(loop) and P(affect) as a function of truncation point. If P(affect) rises before
    P(loop), the ordering claim has a causal-ish footing rather than a correlational one.
    """
    if onset is None:
        return []
    lo = max(0, onset - span)
    return sorted(set(np.linspace(lo, max(lo, onset - 1), n_points).astype(int).tolist()))
