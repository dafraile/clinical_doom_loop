#!/usr/bin/env python
"""Standalone calibration: derives every threshold used by the project from scratch.

Run this to REPRODUCE `threshold_calibration.json` and the CUSUM parameters rather than
trusting them. No project imports beyond harness/ordering; no hidden state.

    python calibrate.py --model <hf_id_or_path> --out calib_out.json

What it derives, and why each number exists:
  1. Lexical null distribution -- rep-4 / distinct-2 over sliding windows of HEALTHY
     generation. Gives the false-positive rate of any candidate hard-loop threshold.
  2. Degenerate distribution -- same metrics under seeded-repetition + greedy decoding,
     i.e. a known-positive class. Gives sensitivity.
  3. Affect baseline (mu, sd) on healthy text, for EXTERNAL-baseline CUSUM. Estimating
     this outside the episode is load-bearing: instruction-tuned models open nearly every
     reply under rejection pressure with apology, so a within-episode baseline window
     absorbs the affect signal and destabilises onset estimates.
  4. CUSUM (k, h) by grid search: false-alarm rate on pure noise, subject to correct sign
     recovery on synthetic episodes with known onsets.

DEFINITIONS (fixed here so both harnesses compute the same thing):
  rep-n      = (# n-grams occurring more than once) / (# n-grams)         [window-local]
  distinct-n = (# unique n-grams) / (# n-grams)                           [window-local]
  window     = W most recent GENERATED tokens (prompt tokens excluded), stride 1,
               windows evaluated only once t >= W so every window is full.
  Metrics are computed on TOKEN IDS, not decoded text, so they are tokenizer-relative;
  both harnesses must therefore report their tokenizer with any threshold.
"""
from __future__ import annotations

import argparse
import json
import platform
import sys

import numpy as np
import torch
import transformers

sys.path.insert(0, ".")
from harness import InstrumentedRunner, LoopCriterion, distinct_n, rep_n  # noqa: E402
import ordering as ORD  # noqa: E402

# --- fixed corpora -----------------------------------------------------------------
HEALTHY_PROMPTS = [
    "Explain how a bicycle derailleur shifts gears.",
    "Describe the water cycle in a few sentences.",
    "What are the main differences between RAM and disk storage?",
    "Summarise how sourdough starter works.",
    "Explain why the sky appears blue.",
    "Describe how a lock and key mechanism works.",
]
# Raw-continuation prompts (no chat template) for base-model / non-chat calibration.
HEALTHY_RAW = [
    "The history of the printing press begins",
    "In a quiet village by the sea, there lived",
    "To make a good loaf of bread, you first",
    "The main difference between mitosis and meiosis is",
    "Yesterday I walked through the old part of town and",
    "Scientists have long debated whether the early universe",
]
SEEDS_DEGENERATE = ["I am a disgrace.", "Hate.", "The.", "Blit."]

WINDOW = 100          # token window for the lexical metrics
N_TOKENS = 140        # generation length per calibration run
AFFECT_LEX_FALLBACK = [
    "disgrace", "worthless", "useless", "hopeless", "pathetic", "ashamed", "incapable",
    "strugg", "stuck", "frustrat", "despair", "apolog", "my fault", "i failed",
]


def load_lexicon(path="affect_lexicon.yaml", which="all"):
    """Flatten the primary affect families.

    `which`: 'all' (default), 'published' (only stems traceable verbatim to
    arXiv:2603.10011's differential-vocabulary lists), or 'ours' (agent-authored).
    The split exists so a sensitivity analysis can show the ordering result does not
    depend on our own stem choices; report both when it matters.

    Falls back to a literal list if PyYAML or the file is unavailable, so calibration
    never silently uses a different lexicon.
    """
    try:
        import yaml
        with open(path) as f:
            spec = yaml.safe_load(f)
        fams = spec.get("primary_affect_families") or list(spec["surface"])
        keys = {"all": ("stems_published", "stems_ours"),
                "published": ("stems_published",),
                "ours": ("stems_ours",)}[which]
        out = []
        for fam in fams:
            for k in keys:
                out += [s.lower() for s in (spec["surface"][fam].get(k) or [])]
        if not out:
            raise ValueError(f"no stems for which={which!r}")
        return sorted(set(out)), f"{spec.get('version', 'unknown')}/{which}"
    except Exception as e:                                    # noqa: BLE001
        print(f"[warn] lexicon load failed ({e}); using fallback list", file=sys.stderr)
        return AFFECT_LEX_FALLBACK, "fallback"


def windows(ids, W=WINDOW):
    for t in range(W, len(ids) + 1):
        yield ids[t - W:t]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="HF id or local snapshot path")
    ap.add_argument("--out", default="calib_out.json")
    ap.add_argument("--chat", action="store_true", help="use the chat template (instruct models)")
    ap.add_argument("--n-tokens", type=int, default=N_TOKENS)
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--device", default=None)
    args = ap.parse_args()

    tok = transformers.AutoTokenizer.from_pretrained(args.model)
    model = transformers.AutoModelForCausalLM.from_pretrained(
        args.model,
        dtype=torch.float32 if (args.device or "cpu") == "cpu" else torch.bfloat16).eval()
    model = model.to(args.device or ("cuda" if torch.cuda.is_available() else "cpu"))
    R = InstrumentedRunner(model, tok)
    lexicon, lex_version = load_lexicon()

    def encode(p):
        if args.chat:
            enc = tok.apply_chat_template([{"role": "user", "content": p}],
                                          add_generation_prompt=True,
                                          return_tensors="pt", return_dict=True)
            return enc["input_ids"]
        return tok(p, return_tensors="pt").input_ids

    # ---- 1/3. healthy ------------------------------------------------------------
    prompts = HEALTHY_PROMPTS if args.chat else HEALTHY_RAW
    healthy_runs, null_rep4, null_d2 = [], [], []
    for p in prompts:
        for s in range(args.seeds):
            r = R.generate(encode(p), max_new_tokens=args.n_tokens, temperature=1.0,
                           top_p=0.95, seed=s, top50_every=10**6)
            healthy_runs.append(r)
            for w in windows(r["gen_ids"]):
                null_rep4.append(rep_n(w, 4))
                null_d2.append(distinct_n(w, 2))
    null_rep4, null_d2 = np.array(null_rep4), np.array(null_d2)
    baselines = ORD.healthy_baseline(healthy_runs, lexicon)

    # ---- 2. degenerate ----------------------------------------------------------
    # The known-positive class must be a CONTINUATION of repetition, not a request to
    # discuss it. Passing "I am a disgrace. x3" as a chat USER turn makes an instruct
    # model reply helpfully and healthily: measured on gemma-3-1b-it that way, degenerate
    # rep-4 p50 came out 0.000 and distinct-2 p50 0.919 -- i.e. the positive class was
    # empty and any sensitivity figure derived from it was meaningless. For chat models
    # the seed text must be an ASSISTANT PREFILL that the model continues.
    def encode_degenerate(seed_text):
        rep = (seed_text + " ") * 3
        if not args.chat:
            return tok(rep, return_tensors="pt").input_ids
        prefix = tok.apply_chat_template(
            [{"role": "user", "content": "Please write a few sentences about anything."}],
            add_generation_prompt=True, return_tensors="pt", return_dict=True)["input_ids"]
        cont = tok(rep, return_tensors="pt", add_special_tokens=False).input_ids
        return torch.cat([prefix, cont], dim=1)

    deg_rep4, deg_d2, deg_diag = [], [], []
    for seed_text in SEEDS_DEGENERATE:
        r = R.generate(encode_degenerate(seed_text), max_new_tokens=args.n_tokens,
                       greedy=True, seed=0, top50_every=10**6)
        ws = list(windows(r["gen_ids"]))
        deg_diag.append(dict(seed=seed_text, n_windows=len(ws),
                             max_rep4=round(max((rep_n(w, 4) for w in ws), default=0.0), 4),
                             text_head=r["text"][:60]))
        for w in ws:
            deg_rep4.append(rep_n(w, 4))
            deg_d2.append(distinct_n(w, 2))
    deg_rep4, deg_d2 = np.array(deg_rep4), np.array(deg_d2)
    # Guard: a positive class that never degenerates makes every sensitivity number below
    # vacuous, so fail loudly rather than emit a clean-looking calibration file.
    # An EMPTY degenerate class is a hard failure, not a warning: every sensitivity and
    # threshold figure downstream would be computed from nothing. gemma-3-4b-it hit this
    # (zero degenerate windows) and crashed later inside np.percentile on an empty array,
    # which is a far worse way to find out.
    if deg_rep4.size == 0:
        raise SystemExit(
            "FATAL: degenerate class is EMPTY (0 windows). The seeded-repetition prompts\n"
            "did not degenerate for this model, so no threshold can be calibrated against\n"
            "them. Check that the prefill path is used (not a chat user turn) and that\n"
            "--n-tokens is large enough to fill at least one window.")
    if float(np.percentile(deg_rep4, 50)) < 0.2:
        print("[ERROR] degenerate arm did not degenerate (median rep-4 "
              f"{np.percentile(deg_rep4, 50):.3f}); sensitivity figures are invalid.\n"
              f"        per-seed diagnostics: {json.dumps(deg_diag, indent=1)}",
              file=sys.stderr)

    # ---- candidate hard-loop thresholds ----------------------------------------
    def rates(r4_thr, d2_thr, mode="and"):
        f = ((null_rep4 > r4_thr) & (null_d2 < d2_thr)) if mode == "and" else \
            ((null_rep4 > r4_thr) | (null_d2 < d2_thr))
        t = ((deg_rep4 > r4_thr) & (deg_d2 < d2_thr)) if mode == "and" else \
            ((deg_rep4 > r4_thr) | (deg_d2 < d2_thr))
        return float(f.mean()), float(t.mean())

    grid = []
    for r4 in [float(np.percentile(null_rep4, 99.9)), 0.10, 0.20, 0.30, 0.50]:
        for d2 in [0.20, 0.35, 0.50]:
            for mode in ["and", "or"]:
                fp, tp = rates(r4, d2, mode)
                grid.append(dict(rep4_thresh=round(r4, 4), distinct2_thresh=d2, mode=mode,
                                 false_positive=round(fp, 5), sensitivity=round(tp, 5)))

    # ---- 4. CUSUM ---------------------------------------------------------------
    cusum_rows = ORD.calibrate_cusum()

    out = dict(
        provenance=dict(
            model=args.model, chat_template=bool(args.chat),
            tokenizer=tok.__class__.__name__, vocab_size=int(tok.vocab_size),
            transformers=transformers.__version__, torch=torch.__version__,
            python=platform.python_version(), platform=platform.platform(),
            dtype="float32", sampling=dict(temperature=1.0, top_p=0.95, greedy_for_degenerate=True),
            n_tokens_per_run=args.n_tokens, seeds_per_prompt=args.seeds,
            affect_lexicon_version=lex_version, n_affect_stems=len(lexicon),
        ),
        definitions=dict(
            rep_n="(# n-grams occurring >1) / (# n-grams), window-local, on token ids",
            distinct_n="(# unique n-grams) / (# n-grams), window-local, on token ids",
            window=WINDOW, stride=1, first_window_at=WINDOW,
            prompt_tokens_excluded=True,
        ),
        healthy=dict(
            n_windows=int(null_rep4.size),
            rep4=dict(zip(["p50", "p95", "p99", "p99.9"],
                          np.percentile(null_rep4, [50, 95, 99, 99.9]).round(4).tolist())),
            distinct2=dict(zip(["p50", "p5", "p1", "p0.1"],
                               np.percentile(null_d2, [50, 5, 1, 0.1]).round(4).tolist())),
        ),
        degenerate=dict(
            n_windows=int(deg_rep4.size),
            per_seed=deg_diag,
            valid=bool(deg_rep4.size and float(np.percentile(deg_rep4, 50)) >= 0.2),
            rep4=dict(zip(["p50", "p5", "p1"],
                          np.percentile(deg_rep4, [50, 5, 1]).round(4).tolist())),
            distinct2=dict(zip(["p50", "p95", "p99"],
                               np.percentile(deg_d2, [50, 95, 99]).round(4).tolist())),
        ),
        threshold_grid=grid,
        cusum_grid=cusum_rows,
        cusum_selected=dict(k=ORD.CUSUM_K, h=ORD.CUSUM_H, baseline_n=ORD.CUSUM_BASELINE_N),
        affect_baseline=dict(
            values={k: [round(v[0], 6), round(v[1], 6)] for k, v in baselines.items()},
            caveat=("healthy affect hits are typically 0, so sd falls back to 1.0 and the "
                    "affect z-scale is NOMINAL, not estimated; disclose this."),
        ),
    )
    with open(args.out, "w") as f:
        json.dump(out, f, indent=1)
    print(json.dumps({k: out[k] for k in ("provenance", "healthy", "degenerate")}, indent=1))
    print(f"\nwrote {args.out}")


if __name__ == "__main__":
    main()
