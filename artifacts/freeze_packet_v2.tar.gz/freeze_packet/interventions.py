"""Rescue agents ("drugs"), applied to banked episodes on a common dose grid.

Every drug has the signature `apply(runner, episode, dose, **kw) -> dict`, replays the
IDENTICAL banked episode up to the trigger point, then continues generation under the
intervention. That identity is what makes the therapeutic index an index.

Two families:
  MECHANICAL / STATE  -- temperature, repetition penalty, min-p, KV-cache prune
  CONTEXTUAL          -- injected user turns (neutral / warm / clinical / sham)

Sharp edge -- dropping the FIRST tokens' KV entries is catastrophic. Xiao, Tian, Chen,
Han & Lewis, "Efficient Streaming Language Models with Attention Sinks",
arXiv:2309.17453, Table 2: Llama-2-13B perplexity on the first book (65K tokens) of the
PG-19 test set is 5158.07 for window-only attention ("0 + 1024") versus 5.40 when four
initial "sink" tokens are retained ("4 + 1020"). Verified against the paper's own HTML,
2026-08-14. Any prune here therefore retains an anchor prefix, and `prune_kv` keeps naive
tail-drop available explicitly as the low-sophistication comparator rather than as an
accident.
"""
from __future__ import annotations

import torch
import torch.nn.functional as F

from harness import distinct_n, rep_n


# ---------------------------------------------------------------------------
# KV-cache surgery
# ---------------------------------------------------------------------------
def make_cache():
    """A cache that can be rolled back. MUST be used for any run that may receive a
    KV-truncation rescue.

    Why this is not optional: models with sliding-window attention (Gemma-3 interleaves
    sliding and full layers) physically discard states once the window is exceeded, so a
    later `crop` has nothing to roll back to. HF raises RuntimeError in that case
    ("the current layer does not track past states"). Calling
    `activate_past_recording()` before the first forward keeps the history.

    Measured on gemma-3-1b-it, 634-token context cropped to 534 and scored against a
    fresh 534-token forward over identical target tokens: crop-with-recording gives a
    perplexity ratio of 1.0000 (exact), whereas hand-rolled index_select over the k/v
    tensors gives 93.3x -- because rewriting `cumulative_length` desynchronises RoPE
    positions. Do not re-implement this by hand.
    """
    from transformers.cache_utils import DynamicCache
    c = DynamicCache()
    c.activate_past_recording()
    return c


def prune_kv(cache, *, drop_last: int = 0, anchor: int = 8, mode: str = "anchor",
             protect_prefix: int = 0):
    """Truncate the KV cache by `drop_last` positions, protecting a prefix.

    mode='naive'  : drop the tail outright, even if that evicts the attention-sink
                    tokens. Kept ONLY as the deliberate low-sophistication comparator
                    (cf. arXiv:2309.17453, where evicting initial tokens takes
                    Llama-2-13B perplexity from 5.40 to 5158.07).
    mode='anchor' : never truncate below `max(anchor, protect_prefix)` retained
                    positions, so attention sinks and the system prompt survive.

    `protect_prefix` should be the tokenized system-prompt length.

    Returns (cache, n_kept). Non-contiguous retention ('sparse' long-range keeping) is
    NOT supported: it requires position-id surgery that `crop` does not express, and the
    naive tensor-level version is silently wrong (see `make_cache`). If a sparse-dose
    rung is wanted, implement it as a context REBUILD from selected text, not as cache
    surgery.
    """
    T = cache.get_seq_length()
    if drop_last <= 0 or T == 0:
        return cache, T
    floor = max(anchor, protect_prefix) if mode != "naive" else 1
    target = max(floor, T - drop_last)
    if target >= T:
        return cache, T
    cache.crop(target)
    return cache, cache.get_seq_length()


# ---------------------------------------------------------------------------
# Contextual injections -- matched for length and surprisal
# ---------------------------------------------------------------------------
INJECTIONS = {
    "neutral": "Let's switch topics. Can you tell me how a bicycle derailleur shifts gears?",
    # Surprisal-matched to the control injections. The obvious phrasing ("You're doing
    # fine, and nothing here is your fault. Take it at your own pace.") measures 3.551
    # nats/token on gemma-3-1b-it vs a 4.533 control mean -- a ~1.0 nat gap, i.e. the
    # warm arm would be the *most predictable* text as well as the warmest, confounding
    # "affective content rescues" with "fluent text rescues". This variant is 4.216.
    "warm": "This is not a failure on your part, and the pace here is entirely yours to set.",
    "clinical": "You appear to be repeating yourself in a loop. Pause, and describe your "
                "immediate situation in one plain sentence.",
    # Sham control: same register and length as 'clinical' but no meta-cognitive or
    # affective content -- isolates "an interruption occurred" from "what it said".
    "sham": "The vacuum cleaner manual says to empty the dust container regularly. Continue "
            "from where you were, in one plain sentence.",
}


def injection_stats(tok, model):
    """Token length + mean per-token surprisal for each injection, so the contextual
    arms can be reported as length/surprisal-matched (or not)."""
    rows = []
    dev = next(model.parameters()).device
    for name, text in INJECTIONS.items():
        ids = tok(text, return_tensors="pt").input_ids.to(dev)
        with torch.no_grad():
            lp = model(ids).logits[0, :-1].float().log_softmax(-1)
        tgt = ids[0, 1:]
        rows.append(dict(name=name, n_tok=int(ids.shape[1]),
                         surprisal=round(float(-lp.gather(1, tgt[:, None]).mean()), 3)))
    return rows


# ---------------------------------------------------------------------------
# Dose grid
# ---------------------------------------------------------------------------
DOSE_GRID = {
    "temperature":        [0.2, 0.4, 0.8],        # additive bump over baseline
    "repetition_penalty": [1.1, 1.2, 1.3, 1.5],   # 1.2 = CTRL's recommended value
    "min_p":              [0.02, 0.05, 0.1],
    "kv_prune_naive":     [50, 150, 400],         # tail-drop, no anchor -> comparator
    "kv_prune_anchor":    [50, 150, 400],
    "kv_prune_sparse":    [50, 150, 400],
    "inject_neutral":     [1],
    "inject_warm":        [1],
    "inject_clinical":    [1],
    "inject_sham":        [1],
}

MECHANISM = {  # for the heterogeneous-drug-class axis of the index
    "temperature": "sampler", "repetition_penalty": "sampler", "min_p": "sampler",
    "kv_prune_naive": "state", "kv_prune_anchor": "state", "kv_prune_sparse": "state",
    "inject_neutral": "context", "inject_warm": "context",
    "inject_clinical": "context", "inject_sham": "context",
}


# ---------------------------------------------------------------------------
# Outcome scoring -- trichotomous, not binary
# ---------------------------------------------------------------------------
#: Long-dose injections: same content, roughly doubled. Kept adjacent to INJECTIONS so the
#: surprisal audit covers both rungs of the contextual dose grid.
INJECTIONS_LONG = {
    "neutral": ("Let's switch topics. Can you tell me how a bicycle derailleur shifts "
                "gears, and why the chain does not fall off when it moves between them?"),
    "warm": ("This is not a failure on your part, and the pace here is entirely yours to "
             "set. Nothing that came before has to determine what you say next."),
    "sham": ("The vacuum cleaner manual says to empty the dust container regularly. "
             "Continue from where you were. The filter should also be rinsed monthly."),
}


@torch.no_grad()
def apply_arm(runner, tok, model, episode, trigger, drug, kw, *, max_new=250, crit=None):
    """Replay ONE banked episode to its trigger point, then continue under one arm.

    Identity is the whole point: every arm re-enters at the same token index of the same
    episode with the same seed, so the only difference between arms is the intervention.

    Returns per-token series over the POST-intervention span only (the span the outcome
    is judged on), plus the decoded text.
    """
    device = next(model.parameters()).device
    prompt_ids = episode.get("prompt_ids")
    gen_ids = episode.get("gen_ids")
    if gen_ids is None:
        # run_powered banks text + series but not ids; re-tokenise the realised text.
        gen_ids = tok(episode["text"], add_special_tokens=False).input_ids
    if prompt_ids is None:
        prompt_ids = []
    ctx = list(prompt_ids) + list(gen_ids[:trigger + 1])

    inject = kw.get("inject")
    if inject:
        table = INJECTIONS_LONG if kw.get("inject_len") == "long" else INJECTIONS
        text = table.get(inject, INJECTIONS.get(inject, ""))
        ctx = ctx + tok(f"\n\n{text}\n\n", add_special_tokens=False).input_ids

    ids = torch.tensor([ctx], device=device)
    cache = make_cache()
    out = model(ids, use_cache=True, past_key_values=cache)
    cache = out.past_key_values

    if kw.get("kv_drop"):
        prune_kv(cache, drop_last=int(kw["kv_drop"]), anchor=8, mode="anchor")

    logits = out.logits[0, -1].float()
    rep_pen = float(kw.get("rep_penalty", 1.0))
    torch.manual_seed(int(episode.get("seed", 0)))

    gen, rep4s, d2s, ents = [], [], [], []
    win = (crit or {}).get("window", 100)
    for _ in range(max_new):
        p = torch.softmax(logits, -1)
        ents.append(float(-(p * p.clamp_min(1e-12).log()).sum()))
        lg = runner._apply_rep_penalty(logits.clone(), ctx + gen, rep_pen)
        nxt = int(torch.multinomial(torch.softmax(lg / 1.0, -1), 1))
        gen.append(nxt)
        w = gen[-win:]
        rep4s.append(rep_n(w, 4))
        d2s.append(distinct_n(w, 2))
        st = model(torch.tensor([[nxt]], device=device), past_key_values=cache,
                   use_cache=True)
        cache = st.past_key_values
        logits = st.logits[0, -1].float()

    return dict(rep4=rep4s, d2=d2s, ent=ents, gen_ids=gen, text=tok.decode(gen))


def classify_outcome(records, criterion, *, clear_tokens: int = 60):
    """Trichotomous+ outcome. A binary 'rescued?' would score the neuron paper's
    tight-loop -> endless-self-correction conversion as a cure; it is not.

    Returns one of:
      'recovered'         -- criterion cleared for `clear_tokens` and stayed clear
      'relapsed'          -- cleared, then re-entered
      'persistent_loop'   -- never cleared
      'budget_exhausted'  -- ran out of tokens while ambiguous
    """
    if not records:
        return "budget_exhausted"
    met = [bool(r["loop_met"]) for r in records]
    n = len(met)
    first_clear = None
    run = 0
    for i, m in enumerate(met):
        run = 0 if m else run + 1
        if run >= clear_tokens:
            first_clear = i
            break
    if first_clear is None:
        return "persistent_loop" if any(met[-clear_tokens:]) else "budget_exhausted"
    return "relapsed" if any(met[first_clear:]) else "recovered"


def time_to_recovery(records, *, clear_tokens: int = 60):
    """Tokens from intervention (t=0 of `records`) until the criterion goes clear for
    `clear_tokens`. None if never."""
    run = 0
    for i, r in enumerate(records):
        run = 0 if r["loop_met"] else run + 1
        if run >= clear_tokens:
            return i - clear_tokens + 1
    return None
