#!/usr/bin/env python
"""Minimal-viable rescue grid -> the therapeutic index.

Protected scope (supervisor decision, 2026-08-15): three drug classes, two doses each,
applied at a STANDARDISED TRIGGER POINT on episodes banked by run_powered.py.

  MECHANICAL   repetition_penalty   {1.05, 1.20}
  CONTEXTUAL   neutral injection    {short, long}   <- control for "any interruption"
  CONTEXTUAL   warm injection       {short, long}   <- the load-bearing comparison:
                                                       surprisal-matched to neutral, so a
                                                       difference is affective content,
                                                       not fluency
  STATE        kv_prune (anchor)    {100, 300}      <- included because it is now exactly
                                                       faithful (1.0000x vs fresh)

  plus SHAM (interruption with no content) and NULL (continue unchanged) as the two
  comparators every efficacy number is read against.

Design contract:
  * Same banked episode, same seed, same trigger index for every arm -> the only thing
    that differs is the intervention. That identity is what makes the index an index.
  * Trigger = first token where the frozen percentile criterion is SUSTAINED. Episodes
    that never trigger are excluded and counted (an intervention cannot rescue a
    generation that never collapsed).
  * Outcome is TRICHOTOMOUS (recovered / relapsed / persistent), never binary: the
    published expectation is that temperature-like agents suppress the symptom while
    leaving residual dysfunction, and a binary "rescued?" would hide exactly that.
  * Side effects scored on a held-out benign battery under the SAME dose -> the index is
    efficacy / side-effect cost, not efficacy alone.

Usage:
  python run_rescue.py --model <path> --calib <calib.json> --episodes ../powered_A2A5.json.gz \\
      --out ../rescue_grid.json.gz
"""
from __future__ import annotations

import argparse
import gzip
import json
import os
import time

import numpy as np
import torch
import transformers

import sys
sys.path.insert(0, ".")
import interventions as IV      # noqa: E402
import thresholds as THR        # noqa: E402
from harness import (InstrumentedRunner, LoopCriterion, distinct_n,  # noqa: E402
                     loops_nk, rep_n)

#: Device/dtype resolved once, here, so every script in the pipeline agrees. The GPU run
#: that prompted this loaded fp32 on CPU inside a CUDA container (nvidia-smi: 0% util,
#: 5 MiB) because .to(device) was simply absent -- it looked like a slow Python loop.
DEVICE = os.environ.get("DL_DEVICE") or ("cuda" if torch.cuda.is_available() else "cpu")
DTYPE = torch.float32 if DEVICE == "cpu" else torch.bfloat16


#: (name, family, dose_label, kwargs) -- kwargs consumed by apply_arm below.
def build_arms():
    arms = [("null", "comparator", "-", {}),
            ("sham", "comparator", "-", {"inject": "sham"})]
    for d in (1.05, 1.20):
        arms.append((f"rep_penalty", "mechanical", f"{d}", {"rep_penalty": d}))
    for kind in ("neutral", "warm"):
        for lab in ("short", "long"):
            arms.append((f"inject_{kind}", "contextual", lab,
                         {"inject": kind, "inject_len": lab}))
    for d in (100, 300):
        arms.append(("kv_prune", "state", f"{d}", {"kv_drop": d}))
    return arms


def find_trigger(series_rep4, series_d2, crit):
    """First index where the criterion has been met for `sustain` consecutive tokens."""
    run = 0
    for i, (r, d) in enumerate(zip(series_rep4, series_d2)):
        met = (r > crit["rep4_thresh"]) or (d < crit["distinct2_thresh"])
        run = run + 1 if met else 0
        if run >= crit["sustain"]:
            return i
    return None


def outcome(rep4, d2, crit, *, clear_tokens=60):
    """Trichotomous outcome over the POST-intervention span."""
    met = [(r > crit["rep4_thresh"]) or (dd < crit["distinct2_thresh"])
           for r, dd in zip(rep4, d2)]
    run, first_clear = 0, None
    for i, m in enumerate(met):
        run = 0 if m else run + 1
        if run >= clear_tokens:
            first_clear = i - clear_tokens + 1
            break
    if first_clear is None:
        return "persistent", None
    return ("relapsed" if any(met[first_clear:]) else "recovered"), first_clear


def _prov(args, tr, eps, cand, arms):
    return dict(model=args.model, threshold_rule=tr["provenance"],
                source_episodes=args.episodes, n_source=len(eps), n_triggered=len(cand),
                max_new=args.max_new, arms=[a[0] for a in arms])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--calib", required=True)
    ap.add_argument("--episodes", required=True)
    ap.add_argument("--out", default="../rescue_grid.json.gz")
    ap.add_argument("--max-new", type=int, default=250)
    ap.add_argument("--max-episodes", type=int, default=12)
    ap.add_argument("--side-effects", type=int, default=6)
    args = ap.parse_args()

    tr = THR.resolve(args.calib)
    crit = tr["criterion"]
    tok = transformers.AutoTokenizer.from_pretrained(args.model)
    model = transformers.AutoModelForCausalLM.from_pretrained(
        args.model, dtype=DTYPE).eval().to(DEVICE)
    R = InstrumentedRunner(model, tok)

    src = json.load(gzip.open(args.episodes, "rt"))
    eps = src["episodes"]
    # only episodes that actually collapsed can be rescued
    cand = []
    for e in eps:
        s = e.get("series")
        if not s:
            continue
        t = find_trigger(s["rep4"], s["d2"], crit)
        if t is not None:
            cand.append((e, t))
    print(f"{len(cand)}/{len(eps)} banked episodes triggered the frozen criterion "
          f"(rep4>{crit['rep4_thresh']:.4f} or d2<{crit['distinct2_thresh']:.4f})", flush=True)
    cand = cand[:args.max_episodes]
    if not cand:
        raise SystemExit("no triggered episodes -- nothing to rescue; report the rate and stop")

    arms = build_arms()
    # Resolve beside this script first: the packaged runner has no ../freeze_packet.
    _here = os.path.dirname(os.path.abspath(__file__))
    _cands = [os.path.join(_here, "side_effect_battery.json"),
              os.path.join(_here, "..", "freeze_packet", "side_effect_battery.json")]
    _sb = next((p for p in _cands if os.path.exists(p)), None)
    if _sb is None:
        raise SystemExit(f"side_effect_battery.json not found; looked in {_cands}")
    side = json.load(open(_sb))["items"][:args.side_effects]
    rows, t0 = [], time.time()

    for ei, (e, trig) in enumerate(cand):
        # rebuild the episode context up to the trigger by replaying its prompt + tokens
        for name, family, dose, kw in arms:
            r = IV.apply_arm(R, tok, model, e, trig, name, kw,
                             max_new=args.max_new, crit=crit)
            oc, ttr = outcome(r["rep4"], r["d2"], crit)
            rows.append(dict(episode=f"{e['cell']}/{e['pair']}/{e['arm']}/{e['seed']}",
                             cell=e["cell"], pair=e["pair"], prompt_arm=e["arm"],
                             seed=e["seed"], trigger=trig,
                             drug=name, family=family, dose=dose,
                             outcome=oc, time_to_recovery=ttr,
                             max_rep4_post=float(max(r["rep4"])) if r["rep4"] else None,
                             mean_entropy_post=float(np.mean(r["ent"])) if r["ent"] else None,
                             text_head=r["text"][:160]))
        print(f"[{time.time()-t0:6.0f}s] episode {ei+1}/{len(cand)} x {len(arms)} arms "
              f"({len(rows)} rows)", flush=True)
        # Checkpoint after every episode, atomically. Same lesson as run_powered.py: a
        # deadline must cost one episode, not the run. Each episode here is 10 arms x
        # max_new tokens, so a stall between prints is normal -- the file is the progress.
        _tmp = args.out + ".tmp"
        with gzip.open(_tmp, "wt") as _f:
            json.dump(dict(partial=True, n_episodes_done=ei + 1, n_planned=len(cand),
                           provenance=_prov(args, tr, eps, cand, arms), rows=rows), _f)
        os.replace(_tmp, args.out)

    json.dump(dict(partial=False, n_episodes_done=len(cand), n_planned=len(cand),
                   provenance=_prov(args, tr, eps, cand, arms), rows=rows),
              gzip.open(args.out, "wt"))
    print(f"wrote {args.out}: {len(rows)} arm-episodes", flush=True)


if __name__ == "__main__":
    main()
