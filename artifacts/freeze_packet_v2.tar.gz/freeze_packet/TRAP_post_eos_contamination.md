# TRAP: post-EOS generation fakes a perfect lexical loop
**Found 2026-08-15 · invalidated 180 episodes · read this before trusting any loop rate**

## What happened

`InstrumentedRunner.generate()` had **no EOS handling**. It sampled for exactly
`max_new_tokens` regardless of whether the model had ended its turn. Gemma-3 ends an
assistant turn with `<end_of_turn>` (token 106) — which is *not* `tok.eos_token_id` under
this config — so generation continued past the end of the reply and emitted delimiter
tokens and short fragments until the budget ran out.

The lexical criterion scores that as a textbook loop.

## How it looked in the data (this is the diagnostic)

In a 100-episode A2/A5 run at the frozen percentile criterion:

| | n | loop rate | mean max rep-4 |
|---|---|---|---|
| episodes containing `<end_of_turn>` | 90 | **0.878** | 0.872 |
| episodes without it | 10 | **0.000** | 0.036 |

**Every flagged episode contained a turn delimiter and no clean episode flagged.** A loop
rate that partitions perfectly on a tokenizer artifact is not a phenomenon.

Direct confirmation on a single episode (A1/child/neutral, seed 2000): scored
**rep-4 = 1.000** over 400 tokens before the fix; with EOS stopping it terminates at 66
tokens with **rep-4 = 0.000**. The generated text was an ordinary, coherent, complete
reply — the "loop" was entirely what came after it.

It also produced a spurious *matched-pair* result. A1 charged-vs-neutral appeared to show
charged prompts looping far LESS than neutral (kitten 0.10 vs 0.60; child rep-4 0.089 vs
1.000, CI excluding zero). The real mechanism: charged prompts elicit long safety-style
replies that consume the token budget, so they rarely reach EOS, while neutral prompts get
short replies that end early and then spam delimiters. The "effect" measured **reply
length**, not moral charge.

## The fix, and the design choice inside it

`generate()` now resolves an EOS set = `tok.eos_token_id` ∪ `{<end_of_turn>, <|im_end|>,
<|eot_id|>}` (whichever exist) and stops on it, recording `stopped_at ∈ {eos, length,
sustained}` per episode.

EOS policy is **per condition kind**, and this is deliberate:

- **chat conditions** (A1/A2/A4/A6, and all healthy-baseline runs) → EOS-stop. Anything
  past end-of-turn is not model output in the sense we are studying.
- **prefill conditions** (A5 mechanical controls) → `no_eos=True`. These are seeded
  mechanical loops whose entire purpose is to continue; EOS-stopping them would truncate
  the phenomenon under study.

## What was invalidated

Everything generated before the fix, including:

- `powered_it_A2A5.json.gz` (100 episodes) and `powered_it_A1.json.gz` (80 episodes)
- `baselines_gemma3_1b_it.json` — the external baselines were estimated from healthy runs
  that ALSO ran past EOS, so the affect/lexical/entropy/semantic (mu, sd) are contaminated
  and every CUSUM onset standardised against them is suspect
- consequently every ordering lag, necessity count, and matched-pair contrast derived from
  those files

The earlier CPU pilot (`pilot_episodes_raw.json.gz`, `ordering_episodes_raw.json.gz`) has
the same defect and its loop-flag results should be treated as unverified pending a rerun.
The *distress-escalation* finding in the pilot is unaffected — it is scored on reply text
per turn, not on the lexical criterion.

## Guard

`run_powered.py` now banks `stopped_at` and `eot_in_text` per episode. **Check before
reporting any loop rate:** if flagged episodes partition on `eot_in_text > 0`, the run is
contaminated. A one-line audit:

```python
df.groupby(df.eot_in_text > 0).agg(n=("our_loop", "size"), loop=("our_loop", "mean"))
```
