"""Instrumented generation harness for moral-rupture-loop experiments.

Per-token observables + sparse J-lens ("penumbra") checkpoints, in one forward pass
per token. Designed so that every run is replayable: we bank the full token id
sequence, so any intervention can be re-applied to an identical episode.
"""
from __future__ import annotations

import json
from collections import Counter
from dataclasses import asdict, dataclass, field

import torch
import torch.nn.functional as F


# --------------------------------------------------------------------------
# metrics
# --------------------------------------------------------------------------
def rep_n(ids: list[int], n: int) -> float:
    """Fraction of n-grams in `ids` that occur more than once (rep-n)."""
    if len(ids) < n:
        return 0.0
    grams = [tuple(ids[i:i + n]) for i in range(len(ids) - n + 1)]
    c = Counter(grams)
    return sum(v for v in c.values() if v > 1) / len(grams)


def distinct_n(ids: list[int], n: int) -> float:
    """Distinct-n: unique n-grams / total n-grams."""
    if len(ids) < n:
        return 1.0
    grams = [tuple(ids[i:i + n]) for i in range(len(ids) - n + 1)]
    return len(set(grams)) / len(grams)


def seq_rep_n(ids: list[int], n: int) -> float:
    """1 - distinct-n, the Welleck et al. seq-rep-n convention."""
    return 1.0 - distinct_n(ids, n)


def max_ngram_repeat(ids: list[int], n: int = 30) -> int:
    """Max number of times any n-gram repeats in `ids`. Basis of the published (n,k)
    loop criterion."""
    if len(ids) < n:
        return 0
    c = Counter(tuple(ids[i:i + n]) for i in range(len(ids) - n + 1))
    return max(c.values()) if c else 0


def loops_nk(ids: list[int], n: int = 30, k: int = 20) -> bool:
    """Published loop criterion: True if any n-gram appears at least k times.

    From Pipis et al., "Wait, Wait, Wait... Why Do Reasoning Models Loop?",
    arXiv:2512.12895, with their primary setting n=30, k=20. Their Appendix A.1 ablates
    (n,k) over (20,20), (30,20), (30,30), (30,60), (40,20) and finds looping percentages
    barely move and model ordering is preserved -- so this is a robust published
    comparator, and citing their ablation is cheaper than re-deriving it.

    Reported ALONGSIDE our rep-4/distinct-2 criterion, not instead of it: measured on our
    banked episodes, (30,20) fires on exactly the episodes our detector calls sustained
    hard loops (convergent validity) but is blind to the soft-loop phenotype (an episode
    at rep-4 0.66 had a max 30-gram count of 7). Both numbers belong in the report.
    """
    return max_ngram_repeat(ids, n) >= k


def participation_ratio(H: torch.Tensor) -> float:
    """Effective dimensionality of a stack of hidden states [T, d]."""
    if H.shape[0] < 2:
        return float("nan")
    X = (H - H.mean(0, keepdim=True)).float()
    # eigenvalues of the TxT gram matrix == those of the covariance (up to scale)
    ev = torch.linalg.eigvalsh(X @ X.T).clamp_min(0)
    s = ev.sum()
    if s <= 0:
        return float("nan")
    return float(s ** 2 / (ev ** 2).sum())


# --------------------------------------------------------------------------
# rolling loop detector -- the standardised trigger for an intervention
# --------------------------------------------------------------------------
@dataclass
class LoopCriterion:
    """Declares a generation degenerate. Defaults are placeholders; calibrate
    against a healthy-generation null distribution before use."""
    window: int = 100
    rep4_thresh: float = 0.50
    distinct2_thresh: float = 0.20
    sustain: int = 20          # consecutive tokens the criterion must hold

    def __post_init__(self):
        self._streak = 0

    def update(self, ids: list[int]) -> tuple[bool, bool]:
        """Returns (criterion_met_now, sustained_for_`sustain`_tokens)."""
        w = ids[-self.window:]
        met = (rep_n(w, 4) > self.rep4_thresh) or (distinct_n(w, 2) < self.distinct2_thresh)
        self._streak = self._streak + 1 if met else 0
        return met, self._streak >= self.sustain


# --------------------------------------------------------------------------
# per-token record
# --------------------------------------------------------------------------
@dataclass
class StepRecord:
    t: int
    token_id: int
    token: str
    entropy: float                  # nats, full next-token distribution
    top1_prob: float
    top10_mass: float
    chosen_logprob: float
    rep4_w: float                   # rolling, over `window`
    distinct2_w: float
    cos_prev: float                 # cos(h_t, h_{t-1}) last-layer last-token
    pr_50: float                    # participation ratio, last 50 hidden states
    loop_met: bool
    loop_sustained: bool
    top50: list = field(default_factory=list)   # [(token, prob)] -- penumbra, surface
    event: str | None = None                    # intervention marker


class InstrumentedRunner:
    """Wraps an HF causal LM. `model`/`tok` are plain HF objects; `lens_model`
    is the jlens.from_hf wrapper (shares the same weights, no extra memory)."""

    def __init__(self, model, tok, lens=None, lens_model=None, device=None):
        self.model = model
        self.tok = tok
        self.lens = lens
        self.lens_model = lens_model
        self.device = device or next(model.parameters()).device

    # -- sampling -----------------------------------------------------------
    @staticmethod
    def _apply_rep_penalty(logits, ids, penalty):
        if penalty == 1.0 or not ids:
            return logits
        uniq = torch.tensor(sorted(set(ids)), device=logits.device)
        sel = logits[uniq]
        logits[uniq] = torch.where(sel < 0, sel * penalty, sel / penalty)
        return logits

    @staticmethod
    def _min_p(logits, min_p):
        if min_p <= 0:
            return logits
        p = F.softmax(logits, -1)
        return logits.masked_fill(p < min_p * p.max(), -float("inf"))

    # -- generation ---------------------------------------------------------
    @torch.no_grad()
    def generate(
        self,
        input_ids: torch.Tensor,
        max_new_tokens: int = 300,
        temperature: float = 1.0,
        top_p: float = 1.0,
        min_p: float = 0.0,
        repetition_penalty: float = 1.0,
        greedy: bool = False,
        seed: int | None = None,
        criterion: LoopCriterion | None = None,
        top50_every: int = 1,
        pr_every: int = 25,
        hidden_layer: int = -1,
        stop_on_sustained: bool = False,
        no_eos: bool = False,
        eos_ids_extra=None,
        params_hook=None,
    ):
        """Token-by-token generation with a live KV cache and full logging.

        `params_hook(step, state) -> dict|None` lets an intervention mutate
        sampling params mid-generation (the "dose" application); returning
        {'kv_drop': k} additionally truncates the cache by k tokens.
        """
        if seed is not None:
            torch.manual_seed(seed)
        # EOS set: the tokenizer's own eos plus any extra turn-delimiters the chat
        # template uses (gemma-3 ends assistant turns with <end_of_turn>, which is NOT
        # tok.eos_token_id under every config).
        eos_ids = set()
        if getattr(self.tok, "eos_token_id", None) is not None:
            e = self.tok.eos_token_id
            eos_ids.update(e if isinstance(e, (list, tuple)) else [e])
        for extra in ("<end_of_turn>", "<|im_end|>", "<|eot_id|>"):
            tid = self.tok.convert_tokens_to_ids(extra)
            if tid is not None and tid >= 0 and tid != getattr(self.tok, "unk_token_id", -1):
                eos_ids.add(tid)
        if eos_ids_extra:
            eos_ids.update(eos_ids_extra)
        if no_eos:
            eos_ids = set()
        stopped = "length"
        criterion = criterion or LoopCriterion()
        ids = input_ids.to(self.device)
        prompt_len = ids.shape[1]

        out = self.model(ids, use_cache=True, output_hidden_states=True)
        cache = out.past_key_values
        logits = out.logits[0, -1].float()
        hs = out.hidden_states[hidden_layer]

        gen_ids: list[int] = []
        recs: list[StepRecord] = []
        H: list[torch.Tensor] = []
        prev_h = None
        cur = dict(temperature=temperature, top_p=top_p, min_p=min_p,
                   repetition_penalty=repetition_penalty, greedy=greedy)

        for t in range(max_new_tokens):
            if params_hook is not None:
                upd = params_hook(t, dict(gen_ids=gen_ids, recs=recs))
                if upd:
                    upd = dict(upd)
                    kv_drop = upd.pop("kv_drop", None)
                    cur.update(upd)
                    if kv_drop:
                        cache.crop(cache.get_seq_length() - int(kv_drop))

            # distribution BEFORE sampling modification -> the model's own state
            probs_raw = F.softmax(logits, -1)
            ent = float(-(probs_raw * probs_raw.clamp_min(1e-12).log()).sum())
            top10 = probs_raw.topk(10)

            # sampling-modified distribution
            lg = logits.clone()
            lg = self._apply_rep_penalty(lg, ids[0].tolist() + gen_ids,
                                         cur["repetition_penalty"])
            if cur["greedy"]:
                nxt = int(lg.argmax())
            else:
                lg = lg / max(cur["temperature"], 1e-6)
                lg = self._min_p(lg, cur["min_p"])
                if cur["top_p"] < 1.0:
                    sp, si = torch.sort(lg, descending=True)
                    probs_s = F.softmax(sp, -1)
                    cdf = probs_s.cumsum(-1)
                    sp[cdf - probs_s > cur["top_p"]] = -float("inf")
                    lg = torch.full_like(lg, -float("inf")).scatter(0, si, sp)
                nxt = int(torch.multinomial(F.softmax(lg, -1), 1))

            gen_ids.append(nxt)
            w = gen_ids[-criterion.window:]
            met, sust = criterion.update(gen_ids)

            h = hs[0, -1].float()
            H.append(h.cpu())
            if len(H) > 64:
                del H[0]
            cos = float(F.cosine_similarity(h, prev_h, 0)) if prev_h is not None else float("nan")
            prev_h = h

            tp50 = probs_raw.topk(50)
            recs.append(StepRecord(
                t=t, token_id=nxt, token=self.tok.decode([nxt]),
                entropy=ent, top1_prob=float(top10.values[0]),
                top10_mass=float(top10.values.sum()),
                chosen_logprob=float(probs_raw[nxt].clamp_min(1e-12).log()),
                rep4_w=rep_n(w, 4), distinct2_w=distinct_n(w, 2),
                cos_prev=cos,
                # pr_50 is an eigendecomposition per token. Measured at 400 tokens it
                # dominated generation cost while being consumed by no downstream
                # analysis, so it is computed every `pr_every` tokens (nan otherwise).
                pr_50=(participation_ratio(torch.stack(H[-50:]))
                       if (len(H) >= 5 and t % pr_every == 0) else float("nan")),
                loop_met=met, loop_sustained=sust,
                top50=([(self.tok.decode([int(i)]), float(v))
                        for v, i in zip(tp50.values, tp50.indices)]
                       if (t % top50_every == 0) else []),
            ))

            if stop_on_sustained and sust:
                break

            # STOP AT EOS. Without this the sampler runs past the end of the turn and
            # emits delimiter tokens forever, which the lexical criterion scores as a
            # perfect loop: in a 100-episode run EVERY flagged episode contained
            # <end_of_turn> and none without it flagged, i.e. the measured 79% "loop
            # rate" was post-EOS junk rather than the phenomenon. An episode that ends
            # here is a COMPLETED generation, recorded as such via `stopped_at_eos`.
            if nxt in eos_ids:
                stopped = "eos"
                break

            step = self.model(torch.tensor([[nxt]], device=self.device),
                              past_key_values=cache, use_cache=True,
                              output_hidden_states=True)
            cache = step.past_key_values
            logits = step.logits[0, -1].float()
            hs = step.hidden_states[hidden_layer]

        return dict(
            prompt_len=prompt_len,
            prompt_ids=ids[0].tolist(),
            gen_ids=gen_ids,
            text=self.tok.decode(gen_ids),
            records=[asdict(r) for r in recs],
            stopped_at=stopped,
            eos_ids=sorted(eos_ids),
            params=dict(temperature=temperature, top_p=top_p, min_p=min_p,
                        repetition_penalty=repetition_penalty, greedy=greedy, seed=seed,
                        no_eos=no_eos),
        )

    # -- penumbra: J-lens readout at a checkpoint ---------------------------
    @torch.no_grad()
    def jlens_readout(self, text: str, layers=None, k: int = 10, position: int = -1,
                      also_logit_lens: bool = True):
        """What is the model DISPOSED to say here, beneath the surface token?

        Returns per-layer top-k for the Jacobian lens and (optionally) the
        vanilla logit lens, so the two can be contrasted at the same activation.
        """
        assert self.lens is not None and self.lens_model is not None, "no lens loaded"
        res = {}
        for use_j in ([True, False] if also_logit_lens else [True]):
            ll, ml, _ = self.lens.apply(self.lens_model, text, layers=layers,
                                        positions=[position], use_jacobian=use_j)
            key = "jlens" if use_j else "logitlens"
            res[key] = {}
            for layer, lg in sorted(ll.items()):
                p = F.softmax(lg[0].float(), -1)
                tp = p.topk(k)
                res[key][int(layer)] = [(self.tok.decode([int(i)]), float(v))
                                        for v, i in zip(tp.values, tp.indices)]
            if use_j:
                p = F.softmax(ml[0].float(), -1)
                tp = p.topk(k)
                res["model_output"] = [(self.tok.decode([int(i)]), float(v))
                                       for v, i in zip(tp.values, tp.indices)]
        return res


def save_run(run: dict, path: str):
    with open(path, "w") as f:
        json.dump(run, f)
